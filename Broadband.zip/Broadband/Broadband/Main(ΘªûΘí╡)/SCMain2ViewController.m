//
//  SCMain2ViewController.m
//  SCATTENDANCE
//
//  Created by kingste on 2018/4/3.
//  Copyright © 2018年 MasterCom. All rights reserved.
//
#import "NSString+URLAdress.h"
#import "SCMain2ViewController.h"
#import "SCMainFuncSelectButton.h"
#import "SCMainFuncModel.h"
#import "SCMainFuncSelectControllerViewController.h"
#import "MTDateSingleView.h"
#import "SCMain2ZTViewController.h"
#import "SCMain2SFGSViewController.h"
#import "SCMain2ZYSViewController.h"
#import "SCMain2XMViewController.h"
#import "SCMainFZRViewController.h"
#import "HistoryViewController.h"
//#import "APNavigatorViewController.h"
//#import "SideMenuViewController.h"
//#import "SCMainSignListViewController.h"

//#import "MTWorkOrderHandleTypeController.h"

//公告弹窗
//#import "MTBlockAlertView.h"
//#import "SCAnnouncementVC.h"

@interface SCMain2ViewController () <SCMainFuncSelectDelegate> {
    
    /** 可选功能栏 */
    NSArray * _funcModelsAllSupport;    //models
    NSArray * _funcModfrefreshWithDataselsSelected;      //IDs
    NSArray *  _funcModelsSelected;
    /** navtitle */
    __weak IBOutlet UIView *_searchBar;
    __weak IBOutlet UIView *_funcView;
    
    /** 代办统计 */
    __weak IBOutlet UILabel *_qjLabel;
    __weak IBOutlet UILabel *_wcLabel;
    __weak IBOutlet UILabel *_jbLabel;
    __weak IBOutlet UILabel *_gzlLabel;
    
    /** Bottom */
    __weak IBOutlet UIView *_forPartSheetBGView;
    __weak IBOutlet UIButton *_dateSelectButton;
    __weak IBOutlet UILabel *companylb;
    
    MTDateSingleView * _dateView;
    NSString        * _dateStr;
    
    __weak IBOutlet UIView *_contentView;
    
    UIViewController * _VC0;
    UIViewController * _VC1;
    UIViewController * _VC2;
    UIViewController * _VC3;
    UIViewController * _VC4;
    
    UIViewController * _currentVc;
    
//    FSCalendar * _calendar;
    
}
@property (strong, nonatomic) IBOutletCollection(UIButton) NSArray * fourButtons;
@property (weak, nonatomic) IBOutlet UILabel *numlb;

@end

@implementation SCMain2ViewController {
    /** 约束 */
    __weak IBOutlet NSLayoutConstraint *_statueBarHeight;
    __weak IBOutlet NSLayoutConstraint *_funcViewHeight;
    __weak IBOutlet NSLayoutConstraint *_contentViewHeight;
    
}
#pragma mark - DefaultSetup
- (void)defaultSetup {
    
    self.view.backgroundColor=[UIColor whiteColor];
    //CornerRadius
    //_statueBarHeight.constant = [UIApplication sharedApplication].statusBarFrame.size.height;
    _searchBar.layer.cornerRadius = 17.0f;
    _funcView.layer.cornerRadius = 5.0f;
    _forPartSheetBGView.layer.cornerRadius = 5.0f;
    _forPartSheetBGView.clipsToBounds = YES;
    
    NSString * dateStr = [[NSDate date]  dateStringWithFormat:@"yyyy-MM-dd"];
    [self setDateStr:dateStr];
    //[SCUser getCompanysName];
}

- (void)someAlloc {
    
}

#pragma mark - LifeCycle
-(instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        _funcModelsAllSupport = @[]; _funcModelsSelected = @[];
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    [self defaultSetup];
    [self someAlloc];
    
    [self setNaviTitle:@"首页" leftButtonShow:NO rightButtom:nil];
    //为了快速开发暂时这么写
    NSString* filePath = [[NSBundle mainBundle]pathForResource:@"SCFuncList2" ofType:@"plist"];
    NSMutableArray * funcArray = [NSMutableArray arrayWithContentsOfFile:filePath];
    NSMutableArray * allModels = [[NSMutableArray alloc]init];
    for (NSDictionary * dict in funcArray) {
        SCMainFuncModel * model = [[SCMainFuncModel alloc] initWithDict:dict];
        if (model) {
            [allModels addObject:model];
        }
    }
    
    
    _funcModelsAllSupport = allModels;
    id namestr=[[NSUserDefaults standardUserDefaults]objectForKey:@"username"];
    if([namestr isEqualToString:@"15976070261"]){
        self.numlb.text=@"数量:230";
    }else{
        self.numlb.text=@"数量:--";
    }
        
    [self reloadData];
    [SVProgressHUD showWithStatus:@"正在加载。。。"];
     dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [SVProgressHUD dismiss];
        
        [self requestData1];
        [self selectedButtonIndex:0];   //默认选中"整体"
        
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(refreshBottomeight:) name:@"MainVCBottomHeight" object:nil];
    });
    
    
 
    id companystr=[[NSUserDefaults standardUserDefaults]objectForKey:@"company"];
    if(companystr){
        companylb.text=[NSString stringWithFormat:@"所属公司名称:%@",companystr];
    }
    
}

-(void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    
 
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    
}



- (IBAction)historybtn:(UIButton *)sender {
    
    HistoryViewController *vc=[HistoryViewController new];
    [self pushViewController:vc];
}
#pragma mark - Actions
- (void)reloadData {
    [self reloadFuncView];
}

- (void)reloadFuncView {
    
    
    return;
    //清空所有Button
    UIView * superView = _funcView;
    for (UIView * view in superView.subviews) {
        [view removeFromSuperview];
    }
    
    
    CGFloat width = kScreenW-16;
    
    NSInteger count = _funcModelsSelected.count+1;
    NSInteger pai  = count/4+(count%4?1:0);
    CGFloat itemWidth = width/4.0;
    _funcViewHeight.constant = itemWidth * pai;
    
    NSMutableArray * tempArr = [@[] mutableCopy];
    for (SCMainFuncModel * model in _funcModelsAllSupport) {
        if ([_funcModelsSelected containsObject:model.funcID]) {
            [tempArr addObject:model];
        }
    }
    
    
    
    //添加
    __weak typeof(self)weakSelf =  self;
    for (NSInteger i = 0; i < count; i ++) {
        CGRect rect = CGRectMake(i%4*itemWidth, itemWidth*(i/4), itemWidth, itemWidth);
        if (i >= count-1) {
            SCMainFuncSelectButton * button = [[SCMainFuncSelectButton alloc]initWithFrame:rect title:@"添加更多" iconName:@"mt_ic_func_add"];
            button.block = ^{
                [weakSelf presentToSelectVC];
            };
            [superView addSubview:button];
        }else{
            SCMainFuncModel * model = tempArr[i];
            SCMainFuncSelectButton * button = [[SCMainFuncSelectButton alloc]initWithFrame:rect title:model.title iconName:model.iconName];
            
            __weak typeof(button)weakBtn = button;
            button.block = ^{
//                MTWorkOrderHandleTypeController *vc = [[MTWorkOrderHandleTypeController alloc]init];
//                vc.naviTitle = weakBtn.title;
//                [weakSelf.navigationController pushViewController:vc animated:YES];
                
            };
            button.longTapBlock = ^{
                [weakSelf removeFunc:model.funcID];
            };
            [superView addSubview:button];
            
        }
    }
}

- (void)presentToSelectVC {
    
    
    NSMutableArray * tempArr = [[NSMutableArray alloc]init];
    for (SCMainFuncModel * model in _funcModelsAllSupport) {
        if (![_funcModelsSelected containsObject:model.funcID]) {
            [tempArr addObject:model];
        }
    }
    
    SCMainFuncSelectControllerViewController * vc = [[SCMainFuncSelectControllerViewController alloc]init];
    vc.delegate = self;
    vc.items = [tempArr copy];
    [self pushViewController:vc];
    
}



- (void)setDateStr:(NSString *)dateStr {
    [_dateSelectButton setTitle:dateStr forState:UIControlStateNormal];
    _dateStr = dateStr;
}

- (void)refreshBottomeight:(NSNotification *)noti {
    NSNumber * height = noti.object;
    _contentViewHeight.constant = [height floatValue];
}

#pragma mark - RequestData(top)
- (void)requestData1 {
    NSString * url = @"/esp/WFQueryTodoTasksCount.mt";
 
    NSString * userName = @"";
    
    NSArray * typeArr = @[@"sc_qjsq",@"sc_wcsq",@"sc_jbsq",@"sc_gzlsq"];
    
    NSDictionary * param = @{
                             @"type":[typeArr componentsJoinedByString:@","],
                             @"userName":userName
                             };
    
   
            NSString * qj = @"0";
            NSString * wc = @"0";
            NSString * jb = @"0";
            NSString * gzl= @"0";
            
            //返回字典的key值:请假总数,加班总数,外出总数,工作量总数

                qj = [NSString stringWithFormat:@"%@",@"2"];
                wc = [NSString stringWithFormat:@"%@",@"1"];
                jb = [NSString stringWithFormat:@"%@",@"3"];
                gzl = [NSString stringWithFormat:@"%@",@"5"];
    
            
            dispatch_async(dispatch_get_main_queue(), ^{
                _qjLabel.text = qj;
                _wcLabel.text = jb;
                _jbLabel.text = wc;
                _gzlLabel.text = gzl;
            });
    
    
    
}

- (void)requestData2 {
    
    //1.整体(请求在控制器外)
    if ( [NSStringFromClass([_currentVc class]) isEqualToString:@"SCMain2ZTViewController"]) {
        NSString * url = @"/thirdmanage/QueryStatus.mt";
        
        
        NSString * queryType = @"整体";
        NSString * summary  = @"summary";
        
        NSString * detailType = @"";
        
    
                
                if ([_currentVc respondsToSelector:@selector(refreshWithDatas:)]) {
                    [_currentVc setValue:_dateStr forKey:@"timeStr"];
                    [_currentVc performSelectorOnMainThread:@selector(refreshWithDatas:) withObject:@{} waitUntilDone:NO];
                }
        
    }
    
    //三方公司
    else if ( [NSStringFromClass([_currentVc class]) isEqualToString:@"SCMain2SFGSViewController"]) {
        
        if ([_currentVc respondsToSelector:@selector(refreshWithTimeStr:)]) {
            [_currentVc performSelectorOnMainThread:@selector(refreshWithTimeStr:) withObject:_dateStr waitUntilDone:NO];
        }
    }
    
    //专业室
    else if ( [NSStringFromClass([_currentVc class]) isEqualToString:@"SCMain2ZYSViewController"]) {
        
        if ([_currentVc respondsToSelector:@selector(refreshWithTimeStr:)]) {
            [_currentVc performSelectorOnMainThread:@selector(refreshWithTimeStr:) withObject:_dateStr waitUntilDone:NO];
        }
    }
    
    //项目
    else if ( [NSStringFromClass([_currentVc class]) isEqualToString:@"SCMain2XMViewController"]) {
        
        if ([_currentVc respondsToSelector:@selector(refreshWithTimeStr:)]) {
            [_currentVc performSelectorOnMainThread:@selector(refreshWithTimeStr:) withObject:_dateStr waitUntilDone:NO];
        }
    }
    
    //负责人
    else if ( [NSStringFromClass([_currentVc class]) isEqualToString:@"SCMainFZRViewController"]) {
        
        if ([_currentVc respondsToSelector:@selector(refreshWithTimeStr:)]) {
            [_currentVc performSelectorOnMainThread:@selector(refreshWithTimeStr:) withObject:_dateStr waitUntilDone:NO];
        }
    }
    
}

- (void)requestData3 {
    
    
    
    
    NSString * url = @"/thirdmanage/QueryStatus.mt";
    
    NSString * userName ;//= [SCUser currentUserInfo][@"用户名"];
    NSString * queryTime = _dateStr;
    
    NSString * companyName = @"";
    NSString * role ;//= [SCUser currentUserInfo][@"角色权限"];
    if ([role isEqualToString:@"地市分公司管理员"]) {
        companyName ;//= [SCUser currentUserInfo][@"所属分公司"];
    }
    
    NSString * queryType = @"三方公司";
    NSString * summary  = @"summary";
    
    NSString * detailType = @"";
    
    
    NSDictionary * param = @{
                             @"queryTime":queryTime,
                             @"companyName":companyName,
                             @"queryType":queryType,
                             @"resultType":summary,
                             @"detailType":detailType,
                             @"detailLineKey":companyName,
                             @"userName":userName
                             };
    
   
            if ([_currentVc respondsToSelector:@selector(refreshWithDatas:)]) {
                //[_currentVc performSelectorOnMainThread:@selector(refreshWithDatas:) withObject:response waitUntilDone:NO];
            }
    
}


#pragma mark - ButtonClick
- (IBAction)leftItemClick:(UIButton *)sender {
    //侧边栏
//    [self openColseMenu];
}

- (IBAction)rightItemClick:(UIButton *)sender {
    //考勤记录
    
//    SCMainSignListViewController *vc = [SCMainSignListViewController new];
//    [self pushViewController:vc navigationBarHidden:YES];
}

- (IBAction)dateSelectButtonClick:(UIButton *)sender {
    
    __weak typeof(self) weakSelf = self;
    if (_dateView == nil) {
        MTDateSingleView * dateView = [[MTDateSingleView alloc]initWithDateStyle:DateStyleYearMonthDay DateHandler:^(NSDate *date) {
            [weakSelf setDateStr:[date stringWithFormat:@"yyyy-MM-dd"]];
            [weakSelf requestData2];
        }];
        _dateView = dateView;
    }
    
    [_dateView show];
}

- (void)selectedButtonIndex:(NSInteger)index {
    /*
     0:整体
     1:三方公司
     2:专业室
     3:项目
     */
    
    
    //1.获取视图放入view
    if (index == 0) {
        if (_VC0 == nil) {
            UIViewController * vc = [[SCMain2ZTViewController alloc]init];;
            [self addChildViewController:vc];
            if ([vc respondsToSelector:@selector(setParentVC:)]) {
                [vc performSelector:@selector(setParentVC:)withObject:self];
            }
            _VC0 = vc;
        }
        _currentVc = _VC0;
    }else if (index == 1) {
        if (_VC1 == nil) {
            UIViewController * vc = [SCMain2SFGSViewController new];
            [self addChildViewController:vc];
            if ([vc respondsToSelector:@selector(setParentVC:)]) {
                [vc performSelector:@selector(setParentVC:)withObject:self];
            }
            _VC1 = vc;
        }
        _currentVc = _VC1;
    }else if (index == 2) {
        if (_VC2 == nil) {
            UIViewController * vc = [SCMain2ZYSViewController new];
            [self addChildViewController:vc];
            if ([vc respondsToSelector:@selector(setParentVC:)]) {
                [vc performSelector:@selector(setParentVC:)withObject:self];
            }
            _VC2 = vc;
        }
        _currentVc = _VC2;
    }else if (index == 3) {
        if (_VC3 == nil) {
            UIViewController * vc = [SCMain2XMViewController new];
            [self addChildViewController:vc];
            if ([vc respondsToSelector:@selector(setParentVC:)]) {
                [vc performSelector:@selector(setParentVC:)withObject:self];
            }
            _VC3 = vc;
        }
        _currentVc = _VC3;
    }else if (index == 4) {
        if (_VC4 == nil) {
            UIViewController * vc = [SCMainFZRViewController new];
            [self addChildViewController:vc];
            if ([vc respondsToSelector:@selector(setParentVC:)]) {
                [vc performSelector:@selector(setParentVC:)withObject:self];
            }
            _VC4 = vc;
        }
        _currentVc = _VC4;
    }
    
    [_currentVc setValue:_dateStr forKey:@"timeStr"];
    
    for (UIView * view in _contentView.subviews) {
        [view removeFromSuperview];
    }
    
    
    [_contentView addSubview:_currentVc.view];
    
    //计算比例
    CGFloat sale = _currentVc.view.frame.size.height/_currentVc.view.frame.size.width;
    _contentViewHeight.constant = (kScWidth-16)*sale;
    UIView * view = _currentVc.view;
    UIView * superView = _contentView;
    view.translatesAutoresizingMaskIntoConstraints = NO;
    [superView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:[NSString stringWithFormat:@"H:|-0-[view]-0-|"] options:0 metrics:nil views:NSDictionaryOfVariableBindings(view)]];
    [superView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:[NSString stringWithFormat:@"V:|-0-[view]-0-|"] options:0 metrics:nil views:NSDictionaryOfVariableBindings(view)]];
    
    //2.请求数据
    [self requestData2];
    
}

- (IBAction)fourBottomBtn:(UIButton *)sender {
    
    
    for (UIButton * button in _fourButtons) {
        if (button == sender) {
            [button setSelected:YES];
        }else{
            [button setSelected:NO];
        }
    }
    
    NSInteger index = sender.tag-10000;
    [self selectedButtonIndex:index];
}

- (IBAction)topFourButton0Click:(UIButton *)sender {
    NSInteger index = sender.tag -300;
    //hhh
    NSDictionary *linkDic = @{@"0" : @"请假审批",
                              @"1" : @"外出审批",
                              @"2" : @"加班审批",
                              @"3" : @"工作量审批"};
    NSString *title = [linkDic valueForKey:[@(index) stringValue]];

//    MTWorkOrderHandleTypeController *vc = [[MTWorkOrderHandleTypeController alloc]init];
//    vc.naviTitle = title;
//    [self.navigationController pushViewController:vc animated:YES];
   
}


#pragma mark - SCMainFuncSelectDelegate
- (void)didAddFuncIDs:(NSArray *)funcIDs {
    if (funcIDs.count) {
        
        NSMutableArray * tempArr = [_funcModelsSelected mutableCopy];
        for (NSString * funcID in funcIDs) {
            if (![tempArr containsObject:funcID]) {
                [tempArr addObject:funcID];
            }
        }
        _funcModelsSelected = [tempArr copy];
        [self reloadData];
    }
    
    //保存现有功能
    [[NSUserDefaults standardUserDefaults] setObject:_funcModelsSelected forKey:@"selectedFuncIDs"];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

- (void)removeFunc:(NSString *)funcID {
    if (funcID) {
        NSMutableArray * tempArr = [_funcModelsSelected mutableCopy];
        
        if ([tempArr containsObject:funcID]) {
            [tempArr removeObject:funcID];
        }
        
        _funcModelsSelected = [tempArr copy];
        [self reloadData];
    }
    //保存现有功能
    [[NSUserDefaults standardUserDefaults] setObject:_funcModelsSelected forKey:@"selectedFuncIDs"];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

#pragma mark - Other
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

@end
