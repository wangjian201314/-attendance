//
//  NSString+URLAdress.h
//  SCATTENDANCE
//
//  Created by wangjian on 2018/6/21.
//  Copyright © 2018年 MasterCom. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (URLAdress)

+(NSString *) connectUrl:(NSMutableDictionary *)params url:(NSString *) urlLink;

@end
