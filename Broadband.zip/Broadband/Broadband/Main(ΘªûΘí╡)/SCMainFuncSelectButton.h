//
//  SCMainFuncSelectButton.h
//  SCATTENDANCE
//
//  Created by kingste on 2018/4/3.
//  Copyright © 2018年 MasterCom. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void(^buttonClick)();
typedef void(^longTapTouch)();

@interface SCMainFuncSelectButton : UIButton

@property (nonatomic, copy)NSString * title;
@property (nonatomic, copy)NSString * iconName;
@property (nonatomic, copy)buttonClick block;
@property (nonatomic, copy)longTapTouch longTapBlock;


- (instancetype)initWithFrame:(CGRect)frame title:(NSString *)title iconName:(NSString *)iconName;



@end
