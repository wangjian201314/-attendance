//
//  SCMain2SFGSViewController.m
//  SCATTENDANCE
//
//  Created by kingste on 2018/4/7.
//  Copyright © 2018年 MasterCom. All rights reserved.
//

#import "HistoryViewController.h"
#import "MTFullScreenSelectView.h"
#import "HeaderViewController.h"
#import "SCMain2SFGSCell.h"
#import "SCUser.h"
#import "ZFBarChart.h"

@interface HistoryViewController () <UITableViewDataSource, UITableViewDelegate,ZFGenericChartDataSource, ZFBarChartDelegate,SCMain2SFGSCellDelegate> {
    
    NSString * _selectedCompany;//默认为 登录账号所在公司
    NSMutableArray * _dataSource;
    
    NSArray * _keys;    //写死的key值
    
    NSArray *_data;
    ZFBarChart * _barChart;
}
@property (weak, nonatomic) IBOutlet UIButton *companybtn;

@end

@implementation HistoryViewController {
    /** 控件 */
    __weak IBOutlet UIView *_topView;
    __weak IBOutlet UIButton * _selectBtn;
    __weak IBOutlet UITableView *_tableView;
    
    __weak IBOutlet UIView *_midView;
}

#pragma mark - LifeCycle
- (instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        NSString * today_date = [[NSDate date] stringWithFormat:@"yyyy-MM-dd"];
        _timeStr = today_date;
        
        _keys = @[@"公司名称",@"员工数量",@"全勤率",@"迟到人数",@"早退人数",@"旷工人数",@"请假人数",@"缺卡人数",@"外出人数",@"出差人数",@"休息人数"];
        [_selectBtn setTitle:today_date forState:UIControlStateNormal];
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    id companystr=[[NSUserDefaults standardUserDefaults]objectForKey:@"company"];
    if(companystr){
        [_companybtn setTitle:[NSString stringWithFormat:@"所属公司名称:%@",companystr] forState:UIControlStateNormal];
    }
    [self setNaviTitle:@"考勤记录" leftButtonShow:YES rightButtom:nil];
    _midView.hidden=YES;
    _dataSource=[NSMutableArray array];
    _selectBtn.hidden = NO;
    NSArray * comps ;//= [SCUser getCompanysName];
    if (comps.count) {
        _selectedCompany = [comps firstObject];
    }else{
        //[SCUser getCompanysName];
    }
    
    //tableView
    _tableView.dataSource = self;
    _tableView.delegate = self;
    _tableView.showsHorizontalScrollIndicator=NO;
    _tableView.shouldGroupAccessibilityChildren=NO;
    _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [_tableView registerNib:[UINib nibWithNibName:@"SCMain2SFGSCell" bundle:nil] forCellReuseIdentifier:@"SCMain2SFGSCell"];
    _tableView.contentInset = UIEdgeInsetsMake(0, 0, 0, 200);
    _tableView.rowHeight = UITableViewAutomaticDimension;
    _tableView.estimatedRowHeight = 30;
    UINib *nib = [UINib nibWithNibName:@"HeaderViewController" bundle:nil];
    HeaderViewController *header = [nib instantiateWithOwner:nil options:nil][0];
    header.frame=CGRectMake(0, 0, 800, 30);
    //_tableView.tableHeaderView = header;
    
    
    
    //_barChart
    ZFBarChart * barChart = [[ZFBarChart alloc]initWithFrame:CGRectMake(0, 0, kScreenW-16, 200)];
    barChart.dataSource = self;
    barChart.delegate = self;
    barChart.unit = @"出勤率%";
    barChart.isResetAxisLineMaxValue = YES;
    barChart.isShowAxisLineValue = NO;
    barChart.isShowYLineSeparate = YES;
    barChart.separateLineStyle = kLineStyleDashLine;
    [_topView addSubview:barChart];
    _barChart = barChart;
    
    [SVProgressHUD showWithStatus:@"正在加载。。。"];
     dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        id namestr=[[NSUserDefaults standardUserDefaults]objectForKey:@"username"];
        if([namestr isEqualToString:@"15976070261"]){
        _data=@[@[@"永盛科技公司",@"120",@"90",@"1",@"0",@"0",@"2",@"2",@"30",@"50",@"23"],
                        @[@"华昌信息技术公司",@"70",@"100",@"",@"0",@"0",@"",@"",@"30",@"20",@"0"],
                        @[@"新飞股份有限公司",@"200",@"95",@"3",@"2",@"3",@"2",@"2",@"60",@"90",@"10"],
                        @[@"咪咕股份有限公司",@"200",@"95",@"3",@"2",@"3",@"2",@"2",@"60",@"90",@"10"],
                        @[@"讯飞科技有限公司",@"450",@"90",@"44",@"2",@"44",@"6",@"2",@"60",@"200",@"30"],
                        @[@"刘生股份有限公司",@"430",@"80",@"4",@"55",@"22",@"55",@"8",@"40",@"260",@"16"],
                        @[@"新飞股份有限公司",@"200",@"95",@"3",@"2",@"3",@"2",@"2",@"60",@"90",@"10"]];
        }
        [SVProgressHUD dismiss];
        [self requestDatas];
    });
    
}

#pragma mark - ButtonsClick
- (IBAction)companyBtnSelect:(UIButton *)sender {
    
    __weak typeof(self) weakSelf = self;
    __weak typeof(sender) weakButton = sender;
    
    
    NSArray * companyName ;//= [SCUser getCompanysName];
    if (companyName.count) {
        MTFullScreenSelectView * selectView = [[MTFullScreenSelectView alloc]initWithStyle:MTFullScreenSelectViewStyleSingle title:@"请选择" selectedbuttons:nil buttons:companyName clickBlock:^(NSArray *selecteds) {
            
            NSString * comp = [selecteds firstObject];
            dispatch_async(dispatch_get_main_queue(), ^{
                _selectedCompany = comp;
                [weakButton setTitle:comp forState:UIControlStateNormal];
                [weakSelf refreshWithTimeStr:_timeStr];
            });
            
        }];
        [selectView show];
    }
    
}

#pragma mark - Actions
- (void)requestDatas {
    
    NSString * url = @"/thirdmanage/QueryStatus.mt";
    
    NSString * userName ;//= [SCUser currentUserInfo][@"用户名"];
    NSString * queryTime = _timeStr;
    
    NSString * companyName = @"";
    NSString * role ;//= [SCUser currentUserInfo][@"角色权限"];
    if ([role isEqualToString:@"地市分公司管理员"]) {
        companyName ;//= [SCUser currentUserInfo][@"所属分公司"];
    }else {
        companyName = _selectedCompany;
    }
    
    NSString * queryType = @"三方公司";
    NSString * summary  = @"summary";
    
    NSString * detailType = @"";
    
    dispatch_async(dispatch_get_main_queue(), ^{
        _dataSource = @[];
        [self reloadData];
    });
    
}

- (void)reloadData {
    [_tableView reloadData];
    
    if (_barChart) {
        [_barChart strokePath];
    }
    
    
    dispatch_time_t delayTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC));
    dispatch_after(delayTime, dispatch_get_main_queue(), ^{
        CGFloat totalHeight = _tableView.contentSize.height+(684-382);
        [[NSNotificationCenter defaultCenter]postNotificationName:@"MainVCBottomHeight" object:@(totalHeight)];
    });
}

-(void)refreshWithTimeStr:(NSString *)timeStr {
    _timeStr = timeStr;
    [self requestDatas];
}

#pragma mark - UITableViewDelegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    
    
    return _data.count;
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    SCMain2SFGSCell * cell = [tableView dequeueReusableCellWithIdentifier:@"SCMain2SFGSCell"];
    
    cell.delegate = self;
    cell.indexPath = indexPath;
    
    
    
    
    NSArray * keys = _keys;
    NSArray * labels = @[cell.label0,
                         cell.label1,
                         cell.label2,
                         cell.label3,
                         cell.label4,
                         cell.label5,
                         cell.label6,
                         cell.label7,
                         cell.label8,
                         cell.label9,
                         cell.lable10];
    
    if(indexPath.row==0){
        
        NSArray *data=@[@"公司",@"总数",@"出勤率",@"迟到",@"早退",@"旷工",@"请假",@"缺卡",@"外出",@"出差",@"休息"];
        for(int i=0;i<labels.count;i++){
            
            UILabel  * label = labels[i];
            label.text = data[i];
            label.textColor=[UIColor colorWithHexString:@"#4682B4"];
            cell.backgroundColor=[UIColor colorWithHexString:@"#DEDEDE"];
        }
    }else{
        
        //NSDictionary * dict  = _dataSource[indexPath.row-1];
        for (NSInteger i = 0; i <11; i ++) {
            UILabel  * label = labels[i];
            label.text = _data[indexPath.row-1][i];
            cell.backgroundColor=[UIColor whiteColor];
        }
    }
    
    return cell;
}

#pragma mark - ZFGenericChartDataSource

- (NSArray *)valueArrayInGenericChart:(ZFGenericChart *)chart{
    
    NSString * key = @"全勤率";
    NSArray * dataArr = [_dataSource copy];
    
    NSMutableArray * tempArr = [@[] mutableCopy];
    for (NSDictionary * dict in dataArr) {
        NSString * value = [[dict[key] componentsSeparatedByString:@"."] firstObject];
        [tempArr addObject:[NSString stringWithFormat:@"%@",value]];
    }
    id namestr=[[NSUserDefaults standardUserDefaults]objectForKey:@"username"];
    if([namestr isEqualToString:@"15976070261"]){
    [tempArr addObjectsFromArray: @[@"90",@"70",@"95",@"95",@"90",@"80",@"90"]];
    }
    return tempArr;
}

- (NSArray *)nameArrayInGenericChart:(ZFGenericChart *)chart{
    NSString * key = @"公司名称";
    NSArray * dataArr = [_dataSource copy];
    
    NSMutableArray * tempArr = [@[] mutableCopy];
    for (NSDictionary * dict in dataArr) {
        [tempArr addObject:dict[key]];
    }
    id namestr=[[NSUserDefaults standardUserDefaults]objectForKey:@"username"];
    if([namestr isEqualToString:@"15976070261"]){
    [tempArr addObjectsFromArray: @[@"永盛科技公司",@"华昌信息技术公司",@"新飞股份有限公司",@"咪咕股份有限公司",@"讯飞科技有限公司",@"刘生股份有限公司",@"新飞股份有限公司"]];
    }
    return tempArr;
}

- (CGFloat)axisLineMaxValueInGenericChart:(ZFGenericChart *)chart{
    return 100;
}

- (NSUInteger)axisLineSectionCountInGenericChart:(ZFGenericChart *)chart{
    return 5;
}

- (void)genericChartDidScroll:(UIScrollView *)scrollView{
    NSLog(@"当前偏移量 ------ %f", scrollView.contentOffset.x);
}

#pragma mark - ZFBarChartDelegate
- (NSArray *)gradientColorArrayInBarChart:(ZFBarChart *)barChart{
    ZFGradientAttribute * gradientAttribute = [[ZFGradientAttribute alloc] init];
    
    UIColor * topColor      = [UIColor colorWithHexString:@"#F79C4F"];
    UIColor * bottomColor   = [UIColor colorWithHexString:@"#FF4E00"];
    
    
    gradientAttribute.colors = @[(id)topColor.CGColor, (id)bottomColor.CGColor];
    gradientAttribute.locations = @[@(0.01), @(0.99)];
    
    return [NSArray arrayWithObjects:gradientAttribute, nil];
}

- (void)barChart:(ZFBarChart *)barChart didSelectBarAtGroupIndex:(NSInteger)groupIndex barIndex:(NSInteger)barIndex bar:(ZFBar *)bar popoverLabel:(ZFPopoverLabel *)popoverLabel{
    NSLog(@"第%ld组========第%ld个",(long)groupIndex,(long)barIndex);
    
    //可在此处进行bar被点击后的自身部分属性设置,可修改的属性查看ZFBar.h
    //    bar.barColor = ZFGold;
    //    bar.isAnimated = YES;
    //    bar.opacity = 0.5;
    //    [bar strokePath];
    
    //可将isShowAxisLineValue设置为NO，然后执行下句代码进行点击才显示数值
    popoverLabel.hidden = NO;
}

- (void)barChart:(ZFBarChart *)barChart didSelectPopoverLabelAtGroupIndex:(NSInteger)groupIndex labelIndex:(NSInteger)labelIndex popoverLabel:(ZFPopoverLabel *)popoverLabel{
    NSLog(@"第%ld组========第%ld个",(long)groupIndex,(long)labelIndex);
    
    //可在此处进行popoverLabel被点击后的自身部分属性设置
    //    popoverLabel.textColor = ZFSkyBlue;
    //    [popoverLabel strokePath];
}

#pragma mark - SCMain2SFGSCellDelegate
- (void)main2SFGSCellDidSelected:(NSIndexPath *)indexPath buttonIndex:(NSInteger)index {
    
    NSArray * detailTypes = @[@"迟到人数",@"早退人数",@"旷工人数",@"请假人数",@"缺卡人数",@"外出人数",@"出差人数",@"休息人数"];
    
    
    NSDictionary * dict = _dataSource[indexPath.row-1];
    
    NSString * comp = dict[@"公司名称"];
    NSString * detailType = detailTypes[index];
    
    
    NSString * url = @"/thirdmanage/QueryStatus.mt";
    
    NSString * userName ;//= [SCUser currentUserInfo][@"用户名"];
    NSString * queryTime = _timeStr;
    
    NSString * companyName = @"";
    NSString * role ;//= [SCUser currentUserInfo][@"角色权限"];
    if ([role isEqualToString:@"地市分公司管理员"]) {
        companyName ;//= [SCUser currentUserInfo][@"所属分公司"];
    }else {
        companyName = _selectedCompany;
    }
    
    NSString * queryType = @"三方公司";
    NSString * resultType  = @"detail";
    
    
    NSDictionary * param = @{
                             @"queryTime":queryTime,
                             @"companyName":companyName,
                             @"queryType":queryType,
                             @"resultType":resultType,
                             @"detailType":detailType,
                             @"detailLineKey":comp,
                             @"userName":userName
                             };
    
    //    [[HttpCommon sharedInstance]requestWithURL:url Params:param LoadingHint:@"加载中..." Handler:^(NSDictionary *response) {
    //
    //        if (response&&[response[@"success"]  isEqualToNumber:@(1)]) {
    //
    //            NSArray * infoArr = response[@"Datas1"];
    //            NSArray * columns = response[@"Columns1"];
    //
    //
    //            NSMutableArray * headerInfoArray=[[NSMutableArray alloc] init];
    //            for (NSString* columnName in columns) {
    //                NSDictionary *headerInfo=@{@"datavalue":columnName,
    //                                           @"datatype":@"String",
    //                                           @"width":@(130),
    //                                           @"iskey":@1,
    //                                           @"canorder":@0,
    //                                           @"extratype":@"CellColor:8"
    //                                           };
    //                [headerInfoArray addObject:headerInfo];
    //            }
    //
    //            NSDictionary * dic=@{@"tableInfo":@{
    //                                         @"bgHeaderColor":@"#D2EBF9",
    //                                         @"bgCellColor":@"#FFFFFF",
    //                                         @"bgCellAltColor":@"#F5F9FE",
    //                                         @"bgFrameColor":@"#F1F1F1",
    //                                         @"bgTopLineColor":@"#439CCA",
    //                                         @"fontColor":@"#000000",
    //                                         @"lineHeight":@30,
    //                                         @"align":@"center",
    //                                         @"selectType":@"Line"
    //                                         },
    //                                 @"headerInfo":headerInfoArray};
    //
    //            dispatch_async(dispatch_get_main_queue(), ^{
    //                //父类跑路
    //                if (_parentVC) {
    //                    //        MTBaseViewController * prentVC = (MTBaseViewController *)self.presentedViewController;
    //
    //                    MTBaseViewController * vc = [[MTTargetMaker sharedInstance]fromClassName:@"SCSheetShowController"];
    //                    [vc setValue:dic forKey:@"tableViewParam"];
    //                    [vc setValue:infoArr forKey:@"datas"];
    //                    [_parentVC pushViewController:vc];
    //                }
    //            });
    //        }
    //    }];
    
}

#pragma mark - Other
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
