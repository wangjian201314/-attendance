//
//  SCMMainSignSearchMasterView.h
//  SCATTENDANCE
//
//  Created by Zone on 2018/4/10.
//  Copyright © 2018年 MasterCom. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void(^BlockButton)(UIButton *button);

typedef void(^BlockData)(UITextField *textField);

@interface SCMMainSignSearchMasterView : UIView

@property (nonatomic, strong) BlockButton blockButton;

@property (nonatomic, strong) BlockData blockData;
@property (weak, nonatomic) IBOutlet UITextField *timeText;
@property (weak, nonatomic) IBOutlet UILabel *clockRsultLabel;
@property (weak, nonatomic) IBOutlet UITextField *nameText;
@property (weak, nonatomic) IBOutlet UILabel *attributionLabel;
@property (weak, nonatomic) IBOutlet UILabel *companyLabel;
@property (weak, nonatomic) IBOutlet UILabel *departmentLabel;
@property (weak, nonatomic) IBOutlet UILabel *professionalLabel;
@property (weak, nonatomic) IBOutlet UITextField *masterText;
@property (weak, nonatomic) IBOutlet UILabel *projectLabel;




@end
