//
//  SCTwoLableTableController.m
//  SCATTENDANCE
//
//  Created by kingste on 2018/4/4.
//  Copyright © 2018年 MasterCom. All rights reserved.
//

#import "SCTwoLableCell.h"

#import "SCTwoLableTableController.h"

@interface SCTwoLableTableController () <UITableViewDataSource, UITableViewDelegate> {
    
    __weak IBOutlet UIView *_tableViewBGView;
    __weak IBOutlet UITableView *_tableView;
}

@end

@implementation SCTwoLableTableController {
    __weak IBOutlet NSLayoutConstraint *_statueBarHeight;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    
    _statueBarHeight.constant = MTIPhoneX?44:20;
    _tableViewBGView.layer.cornerRadius = 5.0f;
    _tableViewBGView.clipsToBounds = YES;
    
    _tableView.dataSource = self;
    _tableView.delegate = self;
    _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [_tableView registerNib:[UINib nibWithNibName:@"SCTwoLableCell" bundle:nil] forCellReuseIdentifier:@"SCTwoLableCell"];
    _tableView.rowHeight = UITableViewAutomaticDimension;
    _tableView.estimatedRowHeight = 44;
}

#pragma mark - UITableViewDlegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _keys?_keys.count:0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    SCTwoLableCell * cell = [tableView dequeueReusableCellWithIdentifier:@"SCTwoLableCell"];
    
    id key      = _keys[indexPath.row];
    id value    = _values[indexPath.row];
    
    cell.label0.text = [NSString stringWithFormat:@"%@",key];
    cell.label1.text = [NSString stringWithFormat:@"%@",value];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

- (IBAction)backBtnnn:(id)sender {
//    [self backAction:sender];
}


#pragma mark - Other
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)dealloc {
    DLog(@"%s",__func__);
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
