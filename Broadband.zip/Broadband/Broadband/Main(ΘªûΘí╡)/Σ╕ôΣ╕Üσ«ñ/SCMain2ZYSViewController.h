//
//  SCMain2ZYSViewController.h
//  SCATTENDANCE
//
//  Created by kingste on 2018/4/7.
//  Copyright © 2018年 MasterCom. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MTBaseViewController.h"
@interface SCMain2ZYSViewController : UIViewController

- (void)refreshWithTimeStr:(NSString *)timeStr;

@property (nonatomic, weak)MTBaseViewController * parentVC;
@property (nonatomic, copy)NSString * timeStr;

@end
