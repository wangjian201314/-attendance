//
//  SCTwoLableCell.m
//  SCATTENDANCE
//
//  Created by kingste on 2018/4/4.
//  Copyright © 2018年 MasterCom. All rights reserved.
//

#import "SCTwoLableCell.h"

@implementation SCTwoLableCell

- (void)awakeFromNib {
    [super awakeFromNib];
    //grayline
    UIView * grayLine = [[UIView alloc]init];
    grayLine.backgroundColor = [UIColor groupTableViewBackgroundColor];
    [self addSubview:grayLine];
    grayLine.translatesAutoresizingMaskIntoConstraints = NO;
    [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:[NSString stringWithFormat:@"H:|-0-[grayLine]-0-|"] options:0 metrics:nil views:NSDictionaryOfVariableBindings(grayLine)]];
    [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:[NSString stringWithFormat:@"V:[grayLine(0.5)]-0-|"] options:0 metrics:nil views:NSDictionaryOfVariableBindings(grayLine)]];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
