//
//  SCMainFuncSelectControllerViewController.h
//  SCATTENDANCE
//
//  Created by kingste on 2018/4/3.
//  Copyright © 2018年 MasterCom. All rights reserved.
//

#import "MTBaseViewController.h"

@class SCMainFuncModel;
@protocol SCMainFuncSelectDelegate <NSObject>

- (void)didAddFuncIDs:(NSArray *)funcIDs;

@end

@interface SCMainFuncSelectControllerViewController : MTBaseViewController

@property (nonatomic, copy)NSArray<SCMainFuncModel *> * items;
@property (nonatomic, assign)id<SCMainFuncSelectDelegate>delegate;

@end
