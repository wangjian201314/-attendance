//
//  HeaderViewController.m
//  SCATTENDANCE
//
//  Created by wangjian on 2018/5/22.
//  Copyright © 2018年 MasterCom. All rights reserved.
//

#import "HeaderViewController.h"

@implementation HeaderViewController


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
    
}
- (id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super initWithCoder:aDecoder];
    if (self) {
        [self initialize];
    }
    return self;
}

- (void)initialize{
    
    self.backgroundColor=[UIColor colorWithHexString:@"#F0F0F0"];
}
@end
