//
//  SCMain2SFGSCell.h
//  SCATTENDANCE
//
//  Created by kingste on 2018/4/9.
//  Copyright © 2018年 MasterCom. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol SCMain2SFGSCellDelegate <NSObject>

- (void)main2SFGSCellDidSelected:(NSIndexPath *)indexPath buttonIndex:(NSInteger)index;

@end

@interface SCMain2SFGSCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *label0;
@property (weak, nonatomic) IBOutlet UILabel *label1;
@property (weak, nonatomic) IBOutlet UILabel *label2;
@property (weak, nonatomic) IBOutlet UILabel *label3;

@property (weak, nonatomic) IBOutlet UILabel *label4;
@property (weak, nonatomic) IBOutlet UILabel *label5;
@property (weak, nonatomic) IBOutlet UILabel *label6;
@property (weak, nonatomic) IBOutlet UILabel *label7;
@property (weak, nonatomic) IBOutlet UILabel *label8;
@property (weak, nonatomic) IBOutlet UILabel *label9;
@property (weak, nonatomic) IBOutlet UILabel *lable10;


@property (nonatomic, copy)NSIndexPath * indexPath;
@property (assign, nonatomic)id <SCMain2SFGSCellDelegate>delegate;

@end
