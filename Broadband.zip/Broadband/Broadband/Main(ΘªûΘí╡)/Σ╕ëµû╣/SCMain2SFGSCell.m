//
//  SCMain2SFGSCell.m
//  SCATTENDANCE
//
//  Created by kingste on 2018/4/9.
//  Copyright © 2018年 MasterCom. All rights reserved.
//

#import "SCMain2SFGSCell.h"

@implementation SCMain2SFGSCell

- (void)awakeFromNib {
    [super awakeFromNib];
    //grayline
    UIView * grayLine = [[UIView alloc]init];
    grayLine.backgroundColor = [UIColor lightGrayColor];
    [self addSubview:grayLine];
    grayLine.translatesAutoresizingMaskIntoConstraints = NO;
    [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:[NSString stringWithFormat:@"H:|-0-[grayLine]-0-|"] options:0 metrics:nil views:NSDictionaryOfVariableBindings(grayLine)]];
    [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:[NSString stringWithFormat:@"V:[grayLine(0.5)]-0-|"] options:0 metrics:nil views:NSDictionaryOfVariableBindings(grayLine)]];
    
    
    
    //addButton
    NSArray * labels = @[_label3,_label4,_label5,_label6,_label7,_label8,_label9,_lable10];
    for (NSInteger i = 0; i < labels.count; i ++) {
        
        UILabel * label = labels[i];
        
        UIButton * button = [UIButton buttonWithType:UIButtonTypeCustom];
        button.tag = 100+i;
        [button addTarget:self action:@selector(buttonClick:) forControlEvents:UIControlEventTouchUpInside];
        
        [label addSubview:button];
        
        button.translatesAutoresizingMaskIntoConstraints = NO;
        [label addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:[NSString stringWithFormat:@"H:|-0-[button]-0-|"] options:0 metrics:nil views:NSDictionaryOfVariableBindings(button)]];
        [label addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:[NSString stringWithFormat:@"V:|-0-[button]-0-|"] options:0 metrics:nil views:NSDictionaryOfVariableBindings(button)]];
    }
}

- (void)buttonClick:(UIButton *)button {
    NSInteger index = button.tag-100;
    
    if(_indexPath.row==0){
        
        return;//第一行不可点击
    }
    if (self.delegate&&[self.delegate respondsToSelector:@selector(main2SFGSCellDidSelected:buttonIndex:)]) {
        //[self.delegate main2SFGSCellDidSelected:_indexPath buttonIndex:index];
    }
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
