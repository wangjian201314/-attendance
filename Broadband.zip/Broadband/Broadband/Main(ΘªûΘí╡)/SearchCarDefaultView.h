//
//  SearchCarDefaultView.h
//  SCATTENDANCE
//
//  Created by duanyutian on 2018/5/31.
//  Copyright © 2018年 MasterCom. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SearchCarDefaultView : UIView

@property (weak, nonatomic) IBOutlet UIButton *staffButton;
@property (weak, nonatomic) IBOutlet UIButton *statusButton;
@property (weak, nonatomic) IBOutlet UIButton *cityButton;
@property (weak, nonatomic) IBOutlet UITextField *numberTextField;
@property (weak, nonatomic) IBOutlet UITextField *nameTextField;
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;
@property (weak, nonatomic) IBOutlet UILabel *numberLabel;

- (void)setUpDataSource:(NSString *)name;

- (void)itemBlock:(void(^)(NSInteger sender))itemClick;
- (void)endEditingBlock:(void(^)(NSString *value, NSInteger tag))kBlock;

@end
