//
//  NSString+URLAdress.m
//  SCATTENDANCE
//
//  Created by wangjian on 2018/6/21.
//  Copyright © 2018年 MasterCom. All rights reserved.
//

#import "NSString+URLAdress.h"

@implementation NSString (URLAdress)

/**
 * 传入参数与url，拼接为一个带参数的url
 **/
+(NSString *) connectUrl:(NSMutableDictionary *)params url:(NSString *) urlLink{
    // 初始化参数变量
    NSString *str = @"&";
    
    // 快速遍历参数数组
    for(id key in params) {
        NSLog(@"key :%@  value :%@", key, [params objectForKey:key]);
        str = [str stringByAppendingString:key];
        str = [str stringByAppendingString:@"＝"];
        NSString *value=[params objectForKey:key];
        if([[params objectForKey:key] isKindOfClass:[NSNumber class]]){
            
            NSNumberFormatter* numberFormatter = [[NSNumberFormatter alloc] init];
            value= [numberFormatter stringFromNumber:[params objectForKey:key]];
        }
        str = [str stringByAppendingString:value];
        str = [str stringByAppendingString:@"&"];
    }
    // 处理多余的&以及返回含参url
    if (str.length > 1) {
        // 去掉末尾的&
        str = [str substringToIndex:str.length - 1];
        // 返回含参url
        return [[urlLink stringByAppendingString:@"?"] stringByAppendingString:str];
    }
    return Nil;
}

@end
