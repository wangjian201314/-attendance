//
//  SCSheetShowController.h
//  SCATTENDANCE
//
//  Created by kingste on 2018/4/4.
//  Copyright © 2018年 MasterCom. All rights reserved.
//

#import "MTBaseViewController.h"

@interface SCSheetShowController : MTBaseViewController

@property (nonatomic, copy)NSDictionary * tableViewParam;
@property (nonatomic, copy)NSArray * datas;

@end
