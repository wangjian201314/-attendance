//
//  SCMainSignSearchView.h
//  SCATTENDANCE
//
//  Created by hqf on 2018/4/4.
//  Copyright © 2018年 MasterCom. All rights reserved.
//

#import <UIKit/UIKit.h>
@class SCMainSignSearchView;
@protocol  SCMainSignSearchViewDelegate<NSObject>

- (void)didSelectBeginTime;
- (void)didSelectEndTime;
- (void)didSelectStatus;
- (void)didSearchAction;
- (void)didCancelAction;

@end

@interface SCMainSignSearchView : UIView
@property (weak, nonatomic) IBOutlet UITextField *beginTimeTextField;
@property (weak, nonatomic) IBOutlet UITextField *endTimeTextField;
@property (weak, nonatomic) IBOutlet UILabel *statusLabel;

@property (nonatomic, weak)id<SCMainSignSearchViewDelegate>delegate;


@end
