//
//  SearchCarDefaultView.m
//  SCATTENDANCE
//
//  Created by duanyutian on 2018/5/31.
//  Copyright © 2018年 MasterCom. All rights reserved.
//

#import "SearchCarDefaultView.h"

@interface SearchCarDefaultView ()

@property (nonatomic, copy) void (^itemClick)(NSInteger sender);
@property (nonatomic, copy) void (^endEditingBlock)(NSString *value, NSInteger tag);

@end

@implementation SearchCarDefaultView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self = [[[NSBundle mainBundle] loadNibNamed:@"SearchCarDefaultView" owner:nil options:nil] lastObject];
        self.backgroundColor = [UIColor whiteColor];
    }
    return self;
}

- (void)setUpDataSource:(NSString *)name {
    if ([name isEqualToString:@"车辆查询"]) {
        self.numberLabel.text = @"车牌号";
        self.nameLabel.hidden = self.nameTextField.hidden = YES;
    } else {
        self.numberLabel.text = @"仪器编号";
        self.nameLabel.hidden = self.nameTextField.hidden = NO;
    }
}

- (void)itemBlock:(void(^)(NSInteger sender))itemClick {
    self.itemClick = itemClick;
}

- (IBAction)itemClick:(UIButton *)sender {
    if (self.itemClick) {
        self.itemClick(sender.tag);
    }
}

- (void)endEditingBlock:(void(^)(NSString *value, NSInteger tag))kBlock {
    self.endEditingBlock = kBlock;
}

- (IBAction)valueChange:(UITextField *)sender {
    if (self.endEditingBlock) {
        self.endEditingBlock(sender.text, sender.tag);
    }
}

@end
