//
//  SCMainFuncSelectControllerViewController.m
//  SCATTENDANCE
//
//  Created by kingste on 2018/4/3.
//  Copyright © 2018年 MasterCom. All rights reserved.
//

#import "SCMainFuncSelectControllerViewController.h"
#import "SCMainFuncSelectCell.h"
#import "SCMainFuncModel.h"

@interface SCMainFuncSelectControllerViewController () <UICollectionViewDataSource,UICollectionViewDelegate> {
    /** 控件 */
    __weak IBOutlet UICollectionView *_colectionView;
    
    /** 数据 */
    NSMutableArray * _selectedFuncIDs;
}

@end

@implementation SCMainFuncSelectControllerViewController

#pragma mark - LifeCycle
- (void)viewDidLoad {
    [super viewDidLoad];
    _selectedFuncIDs = [@[] mutableCopy];
//    self.tabbarItemView = YES;
//    "tabbarItemView": 1
    
    _colectionView.dataSource = self;
    _colectionView.delegate   = self;
    [_colectionView registerNib:[UINib nibWithNibName:@"SCMainFuncSelectCell" bundle:nil] forCellWithReuseIdentifier:@"SCMainFuncSelectCell"];
    
    
    
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.navigationController.delegate = self;
}

#pragma mark - UICollectionViewDelegate
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return 1;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return _items.count;
}

- (CGSize)collectionView:(nonnull UICollectionView *)collectionView layout:(nonnull UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(nonnull NSIndexPath *)indexPath {
    CGFloat width = (kScreenW - 2.5)/4.0;
    return CGSizeMake(width , width);
}

- (__kindof UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    SCMainFuncSelectCell * cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"SCMainFuncSelectCell" forIndexPath:indexPath];
    
    
    SCMainFuncModel * model = _items[indexPath.row];
    
    cell.titleLabel.text = model.title;
    cell.imgView.image = [UIImage imageNamed:model.iconName];
    cell.markImgView.image = [UIImage imageNamed:[_selectedFuncIDs containsObject:model.funcID]?@"ic_exam_multiple_sel":@"ic_exam_radio_unsel"];
    
    
    return cell;
}

-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    [collectionView deselectItemAtIndexPath:indexPath animated:YES];
    
    SCMainFuncModel * model = _items[indexPath.row];
    if ([_selectedFuncIDs containsObject:model.funcID]) {
        [_selectedFuncIDs removeObject:model.funcID];
    }else {
        [_selectedFuncIDs addObject:model.funcID];
    }
    
    [collectionView reloadData];
}

#pragma mark - ButtonClick
- (IBAction)backButton:(UIButton *)sender {
   // [self popViewController];
    [self backAction];
}

- (IBAction)doneClick:(UIButton *)sender {
    if (self.delegate&&[self.delegate respondsToSelector:@selector(didAddFuncIDs:)]) {
        [self.delegate didAddFuncIDs:[_selectedFuncIDs copy]];
    }
    [self backButton:nil];
}


#pragma mark - Other
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)dealloc {
    DLog(@"%s",__func__);
}

@end
