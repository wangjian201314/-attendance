//
//  SCMain2FZRViewController.h
//  SCATTENDANCE
//
//  Created by kingste on 2018/4/7.
//  Copyright © 2018年 MasterCom. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SCMainFZRViewController : UIViewController

- (void)refreshWithTimeStr:(NSString *)timeStr;

@property (nonatomic, copy)NSString * timeStr;

@end
