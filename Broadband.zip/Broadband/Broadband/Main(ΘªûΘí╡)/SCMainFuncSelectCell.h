//
//  SCMainFuncSelectCell.h
//  SCATTENDANCE
//
//  Created by kingste on 2018/4/3.
//  Copyright © 2018年 MasterCom. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SCMainFuncSelectCell : UICollectionViewCell

@property (weak, nonatomic) IBOutlet UILabel        * titleLabel;
@property (weak, nonatomic) IBOutlet UIImageView    * imgView;
@property (weak, nonatomic) IBOutlet UIImageView    * markImgView;


@end
