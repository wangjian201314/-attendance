//
//  SCMainFuncModel.m
//  SCATTENDANCE
//
//  Created by kingste on 2018/4/3.
//  Copyright © 2018年 MasterCom. All rights reserved.
//

#import "SCMainFuncModel.h"

@implementation SCMainFuncModel

- (instancetype)initWithDict:(NSDictionary *)dict {
    if (self = [super init]) {
        
        NSString * funcID   = @"";
        NSString * title    = @"";
        NSString * iconName = @"";
        NSString * target   = @"";
        NSDictionary * params = @{};
        
        if (dict) {
            funcID = dict[@"funcID"];
            title = dict[@"title"];
            iconName = dict[@"iconName"];
            target = dict[@"target"];
            params = dict[@"params"];
        }
        
        [self setValue:funcID forKey:@"funcID"];
        [self setValue:title forKey:@"title"];
        [self setValue:iconName forKey:@"iconName"];
        [self setValue:target forKey:@"target"];
        [self setValue:params forKey:@"params"];
    }
    return self;
}

@end
