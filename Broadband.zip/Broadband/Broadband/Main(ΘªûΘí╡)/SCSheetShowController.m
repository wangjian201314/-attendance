//
//  SCSheetShowController.m
//  SCATTENDANCE
//
//  Created by kingste on 2018/4/4.
//  Copyright © 2018年 MasterCom. All rights reserved.
//

#import "SCTwoLableCell.h"

#import "SCSheetShowController.h"
//#import "MTLockedColumnsTableView.h"

@interface SCSheetShowController () //<MTDataGridTableViewDelegate>
{
    
    __weak IBOutlet UIView *_tableViewBGView;
    __weak IBOutlet UIView *_contentView;
//    MTLockedColumnsTableView *_tableView;
}

@end

@implementation SCSheetShowController {
    __weak IBOutlet NSLayoutConstraint *_statueBarHeight;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    
    _statueBarHeight.constant = [UIApplication sharedApplication].statusBarFrame.size.height;
    
    _tableViewBGView.layer.cornerRadius = 5.0f;
    _tableViewBGView.clipsToBounds = YES;
    
    
    
//    _tableView = [MTLockedColumnsTableView new];
//    [_tableView setValue:self forKey:@"parentDelegate"];
//    _tableView.backgroundColor = [UIColor clearColor];
//    _tableView.layer.cornerRadius = 4.f;
//    _tableView.lockColumnCount=1;
//
//    UIView * view = _contentView;
//    [view addSubview:_tableView];
//    _tableView.translatesAutoresizingMaskIntoConstraints = NO;
//    [view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-0-[_tableView]-0-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(_tableView)]];
//    [view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-0-[_tableView]-0-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(_tableView)]];
//
//    if (_datas&&_tableViewParam) {
//        [_tableView setValuesForKeysWithDictionary:_tableViewParam];
//        [_tableView putDatas:_datas];
//    }
}


#pragma mark - Other
- (IBAction)backBtnnn:(id)sender {
//    [self backAction:sender];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)dealloc {
    DLog(@"%s",__func__);
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
