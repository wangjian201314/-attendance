//
//  SCMain2XMViewController.h
//  SCATTENDANCE
//
//  Created by kingste on 2018/4/7.
//  Copyright © 2018年 MasterCom. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SCMain2XMViewController : UIViewController

- (void)refreshWithTimeStr:(NSString *)timeStr;


@property (nonatomic, copy)NSString * timeStr;

@end
