//
//  SCMainFuncSelectButton.m
//  SCATTENDANCE
//
//  Created by kingste on 2018/4/3.
//  Copyright © 2018年 MasterCom. All rights reserved.
//

#import "SCMainFuncSelectButton.h"

@interface SCMainFuncSelectButton () <UIAlertViewDelegate> {
    UIImageView * _imageView;
    UILabel     * _label;
}

@end

@implementation SCMainFuncSelectButton

- (instancetype)initWithFrame:(CGRect)frame title:(NSString *)title iconName:(NSString *)iconName {
    if (self = [super initWithFrame:frame]) {
        
        _title      = title?title:@"";
        _iconName   = iconName?iconName:@"";
        
        
        
        
        CGSize size = frame.size;
        CGFloat width = size.width/2.0;
        
        
        UIImageView * imageView = [[UIImageView alloc]init];
        imageView.frame = CGRectMake(width/2.0, width/2.0-10, width, width);
        imageView.image = [UIImage imageNamed:_iconName];
        [self addSubview:imageView];
        
        UILabel * label = [[UILabel alloc]init];
        label.frame = CGRectMake(0, CGRectGetMaxY(imageView.frame), size.width, 20);
        label.textAlignment = NSTextAlignmentCenter;
        label.font = [UIFont systemFontOfSize:12];
        label.text = _title;
        [self addSubview:label];
        
        _label = label;
        _imageView = imageView;
        
        
        [self addTarget:self action:@selector(buttonClick) forControlEvents:UIControlEventTouchUpInside];
        UILongPressGestureRecognizer * longTap = [[UILongPressGestureRecognizer alloc]initWithTarget:self action:@selector(longTap:)];
        [self addGestureRecognizer:longTap];
        
    }
    return self;
}

- (void)buttonClick {
    if (_block) {
        _block();
    }
}

- (void)longTap:(UILongPressGestureRecognizer *)ges {
    
    if (ges.state == UIGestureRecognizerStateBegan) {
        
        NSString * message = [NSString stringWithFormat:@"是否删除常用功能\"%@\"",_title];
        [[[UIAlertView alloc]initWithTitle:@"提示" message:message delegate:self cancelButtonTitle:nil otherButtonTitles:@"是",@"否", nil] show];
        
    }
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    
    if (buttonIndex == 0) {
        if (_longTapBlock) {
            _longTapBlock();
        }
    }
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
