//
//  SCMainFuncModel.h
//  SCATTENDANCE
//
//  Created by kingste on 2018/4/3.
//  Copyright © 2018年 MasterCom. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SCMainFuncModel : NSObject

@property (nonatomic, copy)NSString * funcID;

@property (nonatomic, copy)NSString * title;
@property (nonatomic, copy)NSString * iconName;
@property (nonatomic, copy)NSString * target;
@property (nonatomic, copy)NSDictionary * params;

- (instancetype)initWithDict:(NSDictionary *)dict;


@end
