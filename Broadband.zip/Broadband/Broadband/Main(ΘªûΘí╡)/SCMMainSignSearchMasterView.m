//
//  SCMMainSignSearchMasterView.m
//  SCATTENDANCE
//
//  Created by Zone on 2018/4/10.
//  Copyright © 2018年 MasterCom. All rights reserved.
//

#import "SCMMainSignSearchMasterView.h"

@interface SCMMainSignSearchMasterView ()

@end

@implementation SCMMainSignSearchMasterView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        self = [[[NSBundle mainBundle] loadNibNamed:@"SCMMainSignSearchMasterView" owner:nil options:nil] lastObject];
    }
    return self;
}

- (IBAction)buttonAction:(UIButton *)sender {
    if (_blockButton) {
        self.blockButton(sender);
    }
}
- (IBAction)textFieldEditingChangedAction:(UITextField *)sender {
    if (_blockData) {
        self.blockData(sender);
    }
}


@end
