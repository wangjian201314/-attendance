//
//  SCMain2ZTViewController.m
//  SCATTENDANCE
//
//  Created by kingste on 2018/4/4.
//  Copyright © 2018年 MasterCom. All rights reserved.
//

#import "SCMain2ZTViewController.h"
#import "ZFChart.h"

@interface SCMain2ZTViewController ()<ZFPieChartDataSource, ZFPieChartDelegate> {
    //出勤率
    NSArray * _keys;
    NSArray * _values;
    
    __weak IBOutlet UILabel *_label0;
    __weak IBOutlet UILabel *_label1;
    __weak IBOutlet UILabel *_label2;
    __weak IBOutlet UILabel *_label3;
    __weak IBOutlet UIButton *_moreBtn;
    
    //人数
    __weak IBOutlet UILabel *_bLabel0;
    __weak IBOutlet UILabel *_bLabel1;
    __weak IBOutlet UILabel *_bLabel2;
    __weak IBOutlet UILabel *_bLabel3;
    __weak IBOutlet UILabel *_blabel4;
    __weak IBOutlet UILabel *_blabel5;
    __weak IBOutlet UILabel *_blabel6;
    __weak IBOutlet UILabel *_blabel7;
    
    //百分比
    __weak IBOutlet UILabel *_cLabel0;
    __weak IBOutlet UILabel *_cLabel1;
    __weak IBOutlet UILabel *_cLabel2;
    __weak IBOutlet UILabel *_cLabel3;
    __weak IBOutlet UILabel *_cLabel4;
    __weak IBOutlet UILabel *_cLabel5;
    __weak IBOutlet UILabel *_cLabel6;
    __weak IBOutlet UILabel *_cLabel7;
    
    //饼图信息
    ZFPieChart * _pieChart;
    __weak IBOutlet UIView *chartView;
    __weak IBOutlet UIButton *chartBtn0;
    __weak IBOutlet UIButton *chartBtn1;
    __weak IBOutlet UIButton *chartBtn2;
    __weak IBOutlet UIButton *chartBtn3;
    __weak IBOutlet UIButton *chartBtn4;
    __weak IBOutlet UIButton *chartBtn5;
    __weak IBOutlet UIButton *chartBtn6;
    __weak IBOutlet UIButton *chartBtn7;
    NSMutableArray *chartValue;
}

@end

@implementation SCMain2ZTViewController {
    NSDictionary * _response;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _keys = @[];
    _values= @[];
    
    chartValue = [NSMutableArray arrayWithCapacity:0];
    
    
    CGFloat width = 140;//不管什么屏幕都是140
    if(kScreenW<=320){
        width=130;
        chartView.frame=CGRectMake(chartView.frame.origin.x, chartView.frame.origin.y, 130, 130);
    }
    ZFPieChart * pieChart = [[ZFPieChart alloc] initWithFrame:CGRectMake(0, 0, width, width)];
    pieChart.dataSource = self;
    pieChart.delegate = self;
    pieChart.isShadow = NO;
    pieChart.isTranslucent = NO;
    pieChart.percentType = kPercentTypeClear;
    [chartView addSubview:pieChart];
    
//    pieChart.translatesAutoresizingMaskIntoConstraints = NO;
//    [chartView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:[NSString stringWithFormat:@"H:|-0-[pieChart]-0-|"] options:0 metrics:nil views:NSDictionaryOfVariableBindings(pieChart)]];
//    [chartView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:[NSString stringWithFormat:@"V:|-0-[pieChart]-0-|"] options:0 metrics:nil views:NSDictionaryOfVariableBindings(pieChart)]];
    _pieChart = pieChart;
}


#pragma mark - ButtonsClick
- (IBAction)moreBtnClick:(UIButton *)sender {
    
   
}

//请假
- (IBAction)button0Click:(UIButton *)sender {
    [self requestDataWithType:@"请假人数"];
}

//迟到
- (IBAction)button1Click:(UIButton *)sender {
    [self requestDataWithType:@"迟到人数"];
}

//早退
- (IBAction)button2Click:(UIButton *)sender {
    [self requestDataWithType:@"早退人数"];
}

//旷工
- (IBAction)button3Click:(UIButton *)sender {
    [self requestDataWithType:@"旷工人数"];
}
//缺卡
- (IBAction)button4Click:(UIButton *)sender {
    
    [self requestDataWithType:@"缺卡人数"];
}

//外出
- (IBAction)button5click:(UIButton *)sender {
    
    [self requestDataWithType:@"外出人数"];
}
//出差
- (IBAction)button6click:(UIButton *)sender {
    
    [self requestDataWithType:@"出差人数"];
}
//休息
- (IBAction)button7click:(UIButton *)sender {
    
    [self requestDataWithType:@"休息人数"];
}

#pragma mark - Actions
- (void)refreshDateWithData1:(NSDictionary *)datas1 datas2:(NSArray *)datas2 {
    
}

- (void)refreshWithDatas:(NSDictionary *)datas {
    _response = datas;
    
   // NSDictionary    * Datas1    = datas[@"Datas1"];
    
//    NSArray * values1 = [[Datas1 allValues] sortedArrayUsingComparator:^NSComparisonResult(NSString * obj1, NSString * obj2) {
//        CGFloat A = [[[obj1 componentsSeparatedByString:@"%"] firstObject] floatValue];
//        CGFloat B = [[[obj2 componentsSeparatedByString:@"%"] firstObject] floatValue];
//        return (A < B);
//
//    }];
    
    
    NSArray * values1 =@[@"10",@"5",@"15",@"1"];
    NSArray * keys1 =@[@"请假",@"迟到",@"早退",@"旷工"];
//    NSArray * keys1 = [Datas1  keysSortedByValueUsingComparator:^NSComparisonResult(NSString * obj1, NSString * obj2) {
//        CGFloat A = [[[obj1 componentsSeparatedByString:@"%"] firstObject] floatValue];
//        CGFloat B = [[[obj2 componentsSeparatedByString:@"%"] firstObject] floatValue];
//
//        return (A < B);
//    }];
    
    NSArray * labels = @[_label0,_label1,_label2,_label3];
    for (NSInteger i = 0; i < labels.count; i ++) {
        UILabel * label = labels[i];
        id namestr=[[NSUserDefaults standardUserDefaults]objectForKey:@"username"];
        if([namestr isEqualToString:@"15976070261"]){
        label.text = [NSString stringWithFormat:@"%@(%@)",keys1[i],values1[i]];
        }
    }
    
    _keys   = keys1;
    _values = values1;
    
    
//    NSArray         * Datas2 = datas[@"Datas2"];
//    NSDictionary *sumDict = Datas2[0];
//    NSInteger sum = [sumDict[@"总人数"] intValue];
    _pieChart.centerName = @"总人数";
    _pieChart.centerNum = 100;
    
    NSMutableArray * tempArr= [@[@"9",@"10",@"5",@"15",@"1",@"4",@"33",@"27",@"10"] mutableCopy];
    for (NSDictionary * dict in tempArr) {
       
        id namestr=[[NSUserDefaults standardUserDefaults]objectForKey:@"username"];
        if([namestr isEqualToString:@"15976070261"]){
            _bLabel0.text = [NSString stringWithFormat:@"%@",@"10"];
            _cLabel0.text = [NSString stringWithFormat:@"%@",@"5%"];
       
            _bLabel1.text = [NSString stringWithFormat:@"%@",@"5"];
            _cLabel1.text = [NSString stringWithFormat:@"%@",@"5%"];
        
            _bLabel2.text = [NSString stringWithFormat:@"%@",@"15"];
            _cLabel2.text = [NSString stringWithFormat:@"%@",@"15%"];
        
            _bLabel3.text = [NSString stringWithFormat:@"%@",@"1"];
            _cLabel3.text = [NSString stringWithFormat:@"%@",@"1%"];
       
            _blabel4.text = [NSString stringWithFormat:@"%@",@"3"];
            _cLabel4.text = [NSString stringWithFormat:@"%@",@"3%"];
        
            _blabel5.text = [NSString stringWithFormat:@"%@",@"33"];
            _cLabel5.text = [NSString stringWithFormat:@"%@",@"33%"];
        
            _blabel6.text = [NSString stringWithFormat:@"%@",@"25"];
            _cLabel6.text = [NSString stringWithFormat:@"%@",@"25%"];
        
            _blabel7.text = [NSString stringWithFormat:@"%@",@"10"];
            _cLabel7.text = [NSString stringWithFormat:@"%@",@"10%"];
        }
//        sum = sum - [dict[@"人数"] intValue];
//        if (sum<0) {
//            sum = 0;
//        }
//        [tempArr addObject:[NSString stringWithFormat:@"%@",dict[@"人数"]]];
    }
    
   // [tempArr insertObject:[NSString stringWithFormat:@"%ld", sum] atIndex:0];
    
    
    id namestr=[[NSUserDefaults standardUserDefaults]objectForKey:@"username"];
    if([namestr isEqualToString:@"15976070261"]){
    [chartBtn0 setTitle:tempArr[1] forState:UIControlStateNormal];
    [chartBtn1 setTitle:tempArr[2] forState:UIControlStateNormal];
    [chartBtn2 setTitle:tempArr[3] forState:UIControlStateNormal];
    [chartBtn3 setTitle:tempArr[4] forState:UIControlStateNormal];
    if(tempArr.count>5){
        
            [chartBtn4 setTitle:tempArr[5] forState:UIControlStateNormal];
            [chartBtn5 setTitle:tempArr[6] forState:UIControlStateNormal];
            [chartBtn6 setTitle:tempArr[7] forState:UIControlStateNormal];
            [chartBtn7 setTitle:tempArr[8] forState:UIControlStateNormal];
    }

    
    [chartValue removeAllObjects];
    [chartValue addObjectsFromArray:tempArr];
    }
    [_pieChart strokePath];
    [self reloadData];
}

- (void)requestDataWithType:(NSString *)type {
    NSString * url = @"/thirdmanage/QueryStatus.mt";
    
    NSString * userName ;//[SCUser currentUserInfo][@"用户名"];
    NSString * queryTime = _timeStr;
    
    NSString * companyName = @"";
    NSString * role ; //[SCUser currentUserInfo][@"角色权限"];
    if ([role isEqualToString:@"地市分公司管理员"]) {
        companyName ;//[SCUser currentUserInfo][@"所属分公司"];
    }
    
    NSString * queryType = @"整体";
    NSString * resultType  = @"detail";
    
    NSString * detailType = type;
    
    
//    NSDictionary * param = @{
//                             @"queryTime":queryTime,
//                             @"companyName":companyName,
//                             @"queryType":queryType,
//                             @"resultType":resultType,
//                             @"detailType":detailType,
//                             @"detailLineKey":companyName,
//                             @"userName":userName
//                             };
//
//    [[HttpCommon sharedInstance]requestWithURL:url Params:param LoadingHint:@"加载中..." Handler:^(NSDictionary *response) {
//        if (response&&[response[@"success"]  isEqualToNumber:@(1)]) {
//            
//            NSArray * infoArr = response[@"Datas1"];
//            NSArray * columns = response[@"Columns1"];
//            
//            
//            NSMutableArray * headerInfoArray=[[NSMutableArray alloc] init];
//            for (NSString* columnName in columns) {
//                NSDictionary *headerInfo=@{@"datavalue":columnName,
//                                           @"datatype":@"String",
//                                           @"width":@(130),
//                                           @"iskey":@1,
//                                           @"canorder":@0,
//                                           @"extratype":@"CellColor:8"
//                                           };
//                [headerInfoArray addObject:headerInfo];
//            }
//            
//            NSDictionary * dic=@{@"tableInfo":@{
//                                         @"bgHeaderColor":@"#D2EBF9",
//                                         @"bgCellColor":@"#FFFFFF",
//                                         @"bgCellAltColor":@"#F5F9FE",
//                                         @"bgFrameColor":@"#F1F1F1",
//                                         @"bgTopLineColor":@"#439CCA",
//                                         @"fontColor":@"#000000",
//                                         @"lineHeight":@30,
//                                         @"align":@"center",
//                                         @"selectType":@"Line"
//                                         },
//                                 @"headerInfo":headerInfoArray};
//            
//            dispatch_async(dispatch_get_main_queue(), ^{
//                
//               
//                //父类跑路
//                if (_parentVC) {
//                    //        MTBaseViewController * prentVC = (MTBaseViewController *)self.presentedViewController;
//                    
//                    MTBaseViewController * vc = [[MTTargetMaker sharedInstance]fromClassName:@"SCSheetShowController"];
//                    [vc setValue:dic forKey:@"tableViewParam"];
//                    [vc setValue:infoArr forKey:@"datas"];
//                    [_parentVC pushViewController:vc];
//                }
//            });
//        }
//    }];
}

- (void)reloadData {
    
    
    
    dispatch_time_t delayTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC));
    dispatch_after(delayTime, dispatch_get_main_queue(), ^{
        CGFloat totalHeight = 500;
        [[NSNotificationCenter defaultCenter]postNotificationName:@"MainVCBottomHeight" object:@(totalHeight)];
    });
}


#pragma mark - ZFPieChartDataSource

- (NSArray *)valueArrayInPieChart:(ZFPieChart *)chart{
    return chartValue;
}

- (NSArray *)colorArrayInPieChart:(ZFPieChart *)chart{
    
    return @[[UIColor blueColor],ZFColor(103, 247, 255, 1), ZFColor(255, 221, 0, 1), ZFColor(255, 101, 104, 1), ZFColor(253, 0, 255, 1), ZFColor(79, 136, 255, 1),ZFColor(79, 171, 0, 1), ZFColor(149, 0, 255, 1), ZFColor(79, 255, 0, 1), ZFColor(197, 79, 170, 1)];
}

#pragma mark - ZFPieChartDelegate   

- (void)pieChart:(ZFPieChart *)pieChart didSelectPathAtIndex:(NSInteger)index{
    NSLog(@"第%ld个",(long)index);
}

- (CGFloat)allowToShowMinLimitPercent:(ZFPieChart *)pieChart{
    return 100000.f;
}

- (CGFloat)radiusForPieChart:(ZFPieChart *)pieChart{
    return chartView.frame.size.width/2.0;
}

/** 此方法只对圆环类型(kPieChartPatternTypeForCirque)有效 */
- (CGFloat)radiusAverageNumberOfSegments:(ZFPieChart *)pieChart{
    return 2.f;
}


#pragma mark - Other
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end



