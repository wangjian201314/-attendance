//
//  HeaderViewController.h
//  SCATTENDANCE
//
//  Created by wangjian on 2018/5/22.
//  Copyright © 2018年 MasterCom. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HeaderViewController : UIView

@end
