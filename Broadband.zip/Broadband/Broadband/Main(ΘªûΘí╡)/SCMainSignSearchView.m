//
//  SCMainSignSearchView.m
//  SCATTENDANCE
//
//  Created by hqf on 2018/4/4.
//  Copyright © 2018年 MasterCom. All rights reserved.
//

#import "SCMainSignSearchView.h"

@implementation SCMainSignSearchView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        self = [[[NSBundle mainBundle] loadNibNamed:@"SCMainSignSearchView" owner:nil options:nil] lastObject];
    }
    return self;
}

- (IBAction)beginTimeAction:(id)sender {
    if (self.delegate&&[self.delegate respondsToSelector:@selector(didSelectBeginTime)]) {
        [self.delegate didSelectBeginTime];
    }
}

- (IBAction)endTimeAction:(id)sender {
    if (self.delegate&&[self.delegate respondsToSelector:@selector(didSelectEndTime)]) {
        [self.delegate didSelectEndTime];
    }
}
- (IBAction)statusAction:(id)sender {
    if (self.delegate&&[self.delegate respondsToSelector:@selector(didSelectStatus)]) {
        [self.delegate didSelectStatus];
    }
}

- (IBAction)searchAction:(id)sender {
    if (self.delegate&&[self.delegate respondsToSelector:@selector(didSearchAction)]) {
        [self.delegate didSearchAction];
    }
}

- (IBAction)cancelAction:(id)sender {
    if (self.delegate&&[self.delegate respondsToSelector:@selector(didCancelAction)]) {
        [self.delegate didCancelAction];
    }
}

- (IBAction)endTimeTextField:(id)sender {
}
@end
