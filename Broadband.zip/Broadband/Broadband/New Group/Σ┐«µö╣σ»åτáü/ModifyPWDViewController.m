//
//  ModifyPWDViewController.m
//  Broadband
//
//  Created by Mac on 2019/5/20.
//  Copyright © 2019年 Mac. All rights reserved.
//

#import "ModifyPWDViewController.h"

@interface ModifyPWDViewController ()
@property (weak, nonatomic) IBOutlet UITableView *mytableview;
@property (weak, nonatomic) IBOutlet UITextField *oldtextfield;
@property (weak, nonatomic) IBOutlet UITextField *newtextfield;
@property (weak, nonatomic) IBOutlet UIButton *uploadbtn;
@property (weak, nonatomic) IBOutlet UITextField *confirmtextfield;

@end

@implementation ModifyPWDViewController
- (IBAction)uploadbtn:(UIButton *)sender {
    
    if([_oldtextfield.text isEqualToString:@""] || [_newtextfield.text isEqualToString:@""] || [_confirmtextfield.text isEqualToString:@""]){
        [SVProgressHUD showErrorWithStatus:@"输入密码不能为空!"];
        return;
    }
    if(_oldtextfield.text.length ==0 || _newtextfield.text.length==0 || _confirmtextfield.text.length==0){
        [SVProgressHUD showErrorWithStatus:@"输入密码不能为空!"];
        return;
    }
    if(![_newtextfield.text isEqualToString:_confirmtextfield.text]){
        [SVProgressHUD showErrorWithStatus:@"2次输入密码不一致，请重新填写!"];
        return;
    }
    [SVProgressHUD showWithStatus:@""];
     dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [SVProgressHUD dismiss];
        [SVProgressHUD showSuccessWithStatus:@"密码修改成功!"];
//        [self backAction];
    });
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [self setNaviTitle:@"修改密码" leftButtonShow:YES rightButtom:nil];
    self.uploadbtn.layer.cornerRadius = 8.0;//2.0是圆角的弧度，根据需求自己更改
//    self.uploadbtn.layer.borderColor = [UIColor colorWithHexString:@"#4182F7"].CGColor;//设置边框颜色
//    self.uploadbtn.layer.borderWidth = 1.0f;//设置边框颜色
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
