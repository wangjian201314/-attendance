//
//  MyViewController.m
//  Broadband
//
//  Created by Mac on 2019/5/20.
//  Copyright © 2019年 Mac. All rights reserved.
//

#import "MyViewController.h"
#import "MyTableViewCell.h"
#import "FacebackViewController.h"
#import "RecentlyViewController.h"
#import "ModifyPWDViewController.h"
#import "LoginViewController.h"
#import "AppDelegate.h"
@interface MyViewController ()<UITableViewDelegate,UITableViewDataSource>{
    
    NSArray *_imgdata;
    NSArray *_datasource;
}
@property (weak, nonatomic) IBOutlet UITableView *mytableView;
@property (weak, nonatomic) IBOutlet UILabel *companylb;

@end

@implementation MyViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
   
    [self setNaviTitle:@"我的" leftButtonShow:NO rightButtom:nil];
    _imgdata=@[@"me_pwd",@"me_setup",@"me_update",@"me_about"];
    _datasource=@[@"修改密码",@"最近处理",@"意见反馈",@"退出"];
    _mytableView.delegate=self;
    _mytableView.dataSource=self;
//    _mytableView.estimatedRowHeight=200;
    _mytableView.showsVerticalScrollIndicator=NO;
    _mytableView.tableFooterView=[[UIView alloc]initWithFrame:CGRectZero];
    [self.view addSubview:_mytableView];
    [_mytableView registerNib:[UINib nibWithNibName:@"MyTableViewCell" bundle:nil] forCellReuseIdentifier:@"MyTableViewCell"];
    
    id companystr=[[NSUserDefaults standardUserDefaults]objectForKey:@"company"];
    if(companystr){
        _companylb.text=[NSString stringWithFormat:@"所属公司名称:%@",companystr];
    }
}

#pragma mark - UITableView Datasource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _datasource.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    
    MyTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MyTableViewCell"];
    
    if(cell == nil) {
        cell = [[MyTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"MyTableViewCell"];
    }
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
    cell.imgview.image=[UIImage imageNamed:_imgdata[indexPath.row]];
    cell.textlb.text=_datasource[indexPath.row];
    
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return 50;
}
#pragma mark - UITableView Delegate methods

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    switch (indexPath.row) {
        case 0:{
            
            
            ModifyPWDViewController *vc=[ModifyPWDViewController new];
            [self pushViewController:vc];
        }
            
            break;
        case 1:{
            
            
            RecentlyViewController *vc=[RecentlyViewController new];
            [self pushViewController:vc];
        }
            
            break;
       
        case 2:{
            FacebackViewController *vc=[FacebackViewController new];
            [self pushViewController:vc];
        }
            
            break;
        case 3:{
            NSNumber * autLogin = [[NSUserDefaults standardUserDefaults] objectForKey:@"autologin"];
            if(!autLogin || ![autLogin isEqual:@(1)]){
                [SVProgressHUD showErrorWithStatus:@"请先登录！"];
            }else{
                [SVProgressHUD showWithStatus:@"退出登录..."];
                 dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                    [SVProgressHUD dismiss];
                    LoginViewController *login=[LoginViewController new];
                    [self.navigationController presentViewController:login animated:YES completion:nil];
                    [[NSUserDefaults standardUserDefaults]setObject:@(0) forKey:@"autologin"];
                    [[NSUserDefaults standardUserDefaults]setObject:@"" forKey:@"username"];
                    
                    
                });
            }
        }
            
            break;
            
        default:
            break;
    }
    
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
