//
//  SCOrderDetailInfoController.m
//  SCATTENDANCE
//
//  Created by mastercom on 2018/4/4.
//  Copyright © 2018年 MasterCom. All rights reserved.
//

#import "SCOrderDetailInfoController.h"
#import "HBDFMultiRowLabelCell.h" // 多行标签
#import "HBDFUploadIconCell.h"

//#import "SCOrderConstant.h"
//#import "SCWXCreateOrderController.h"

@interface SCOrderDetailInfoController ()<UITableViewDelegate,UITableViewDataSource>
{
    NSArray * _columns;
    UITableView *_myTableView;
    NSMutableArray *_dataSource;
    NSDictionary *_configDic; // 本地 创建表单 plist
    UIButton *submitBtn;
    UIView *_bottomView; // 底部处理视图
}
@end

@implementation SCOrderDetailInfoController

#pragma mark - Life cycle
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self.view setBackgroundColor:[UIColor whiteColor]];
    [self setNaviTitle:@"工单详情" leftButtonShow:YES rightButtom:nil];
    
    [self initDatas];
    
    [self layoutUI];
    
    // 仅在待处理入口查看时,才获取处理权限
//    if(_operationIndex == 0)
//    {
    
    
    if(![isnull(_orderInfo[@"工单当前状态"]) isEqualToString:@"已完成"]){
        
        [self updateTableLayout];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Init datas
- (void)initDatas {
  _dataSource = [[NSMutableArray alloc]init];
  
  // 解析本地配置
  NSString *localPath = [[NSBundle mainBundle] pathForResource:@"scwxorderdetail.plist" ofType:nil];
  _configDic = [NSDictionary dictionaryWithContentsOfFile:localPath];
  _columns =  [_configDic valueForKey:[NSString stringWithFormat:@"%@_Columns",_naviTitle]];
  
    
}


/**
 请求工单处理权限
 WFVerifyProcessTask
 */
//- (void)requestHandleAuthDatas
//{
//    NSDictionary *param = @{@"type" : noNullStr([[SCOrderConstant orderTypeDic] valueForKey:_naviTitle]),
//                            @"username": noNullStr([SCOrderConstant username]),
//                            @"taskSN" : noNullStr(_orderInfo[@"工单流水号"]),
//                            @"status" : noNullStr(_orderInfo[@"工单当前状态值"])};
//
//    [[HttpCommon sharedInstance] requestWithURL:[SCOrderConstant WFVerifyProcessTask] Params:param LoadingHint:nil Handler:^(NSDictionary *response) {
//
//        dispatch_async(dispatch_get_main_queue(), ^{
//
//            if([response[@"success"] isEqualToNumber:@1])
//            {
//
//                //[Response] >>> {"success":1,"Datas":{"Enabled":false},"result":""}
//                if ([[response[@"Datas"] objectForKey:@"Enabled"] isEqualToNumber:@(1)])
//                {
//                    // 显示底部处理按钮
//                    [self updateTableLayout];
//                }
//            }
//        });
//    }];
//}
#pragma mark - Lay out
- (void)layoutUI
{
    // bottom
    _bottomView = [[UIView alloc]initWithFrame:CGRectMake(0, kScreenH -(MTIPhoneX?88:64), kScreenW, 0)];
    [self.view addSubview:_bottomView];
   submitBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    submitBtn.frame = CGRectMake(15, 4, kScreenW - 30, 40);
    [_bottomView addSubview:submitBtn];
    [submitBtn setTitle:@"处理" forState:UIControlStateNormal];
    [submitBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    
    [submitBtn addTarget:self action:@selector(handleAction:) forControlEvents:UIControlEventTouchUpInside];
    [submitBtn setBackgroundColor:[UIColor colorWithHexString:@"#2090cc"]];

    _myTableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, kScreenW, kScreenH -(MTIPhoneX?88:64) - CGRectGetHeight(_bottomView.frame)) style:UITableViewStylePlain];
    [self.view addSubview:_myTableView];
    
    [_myTableView registerNib:[UINib nibWithNibName:@"HBDFMultiRowLabelCell" bundle:nil] forCellReuseIdentifier:@"HBDFMultiRowLabelCell"];
  
  [_myTableView registerNib:[UINib nibWithNibName:@"HBDFUploadIconCell" bundle:nil] forCellReuseIdentifier:@"HBDFUploadIconCell"];

  
    _myTableView.delegate = self;
    _myTableView.dataSource = self;
    
    _myTableView.tableFooterView = [[UIView alloc]initWithFrame:CGRectZero];
    _myTableView.estimatedRowHeight = 60.0f;
    _myTableView.rowHeight = UITableViewAutomaticDimension;
}

- (void)updateTableLayout
{
    NSLog(@"updateTableLayout--");

    _bottomView.frame = CGRectMake(0, kScreenH -(MTIPhoneX?88:64) - 49.0f, kScreenW, 49.0f);
    _myTableView.frame = CGRectMake(0, 0, kScreenW, kScreenH -(MTIPhoneX?88:64) - CGRectGetHeight(_bottomView.frame));
}

#pragma mark - Call backs

/**
 区别于 类型:(请假申请/ 工作量) 当前状态:(申请中/ 审批中)
 处理页复用创建页
 */
- (void)handleAction:(id)sender
{
    [SVProgressHUD showWithStatus:@"正在处理工单..."];
    //GCD延迟
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [SVProgressHUD dismiss];
        [[[UIToastView alloc]initWithTitle:@"处理完成"]show];
        [submitBtn setBackgroundColor:[UIColor grayColor]];
        submitBtn.enabled=NO;
    });
    //
//    SCWXCreateOrderController *vc = [[SCWXCreateOrderController alloc]init];
//    vc.naviTitle = _naviTitle;
//    //!
//    vc.handleOrderInfo = _orderInfo;
//    [self.navigationController pushViewController:vc animated:YES];
}

#pragma mark - Table view data source /delegate
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [_columns count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
 
  NSString *title = _columns[indexPath.row];
  if ([title containsString:@"+"]) {
    title = [title stringByReplacingOccurrencesOfString:@"+" withString:@""];
  }
  
  
  if ([title isEqualToString:@"上传里程数照片"]) {
    HBDFUploadIconCell *updataCell = [tableView dequeueReusableCellWithIdentifier:@"HBDFUploadIconCell"];
    updataCell.titleNameLabel.text = title;
    updataCell.countLabel.hidden = YES;
    updataCell.showAddBtn = NO;
    
    NSString *taskId = _orderInfo[@"id"];

    NSString *value = isnull([_orderInfo valueForKey:title]);
    NSArray *array = [value componentsSeparatedByString:@"$"];
      
      // NSString *hostUrl = [NSString stringWithFormat:@"%@?type=%@&taskID=%@&fieldID=23",[SCOrderConstant downloadUrl],noNullStr([[SCOrderConstant orderTypeDic] valueForKey:_naviTitle]),taskId];
    
    NSMutableArray *imageArray = [[NSMutableArray alloc] init];
    for (NSInteger i = 0 ; i < array.count; i++) {
//      NSString *imgUrl = [NSString stringWithFormat:@"%@&fileName=%@",hostUrl,array[i]];
//      MTImagePickerModel *imageModel = [[MTImagePickerModel alloc] init];
//      imageModel.url = imgUrl;
//      imageModel.imgName = array[i];
//      [imageArray addObject:imageModel];
    }

    //
    [updataCell refreshUI:imageArray];

    return updataCell;
  }
  
  
  HBDFMultiRowLabelCell *cell = [tableView dequeueReusableCellWithIdentifier:@"HBDFMultiRowLabelCell"];
  cell.titleNameLabel.text = [NSString stringWithFormat:@"%@:",title];
  cell.valueLabel.text = isnull([_orderInfo valueForKey:title]);
  cell.titleNameLabel.textColor = [UIColor blackColor];
  cell.bottomLineLabel.hidden = YES;
  
  cell.valueLabel.textColor = [UIColor colorWithHexString:@"#1a8ac6"];
  cell.valueLabel.textAlignment = NSTextAlignmentRight;
    cell.valueLabel.text=_datas[indexPath.row];
  
  if([title isEqualToString:@"基本信息"]|| [title isEqualToString:@"项目负责人审批"] || [title isEqualToString:@"科室负责人审批"] || [title isEqualToString:@"省中端管理员审批"]) {
    cell.titleNameLabel.text = title;
    cell.titleNameLabel.textColor = [UIColor brownColor];
    cell.bottomLineLabel.hidden = NO;
    cell.valueLabel.text=@"";
  }
  
  return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return 35.0f;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
  NSString *title = _columns[indexPath.row];
  if ([title isEqualToString:@"上传里程数照片"]) {
    return 120.0f;
  }
 // return 44.0f;
    return UITableViewAutomaticDimension;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *headerView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, kScreenW, 35)];
    headerView.backgroundColor = [UIColor whiteColor];
    UILabel *titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(10, 5, kScreenW - 20, 25)];
    [headerView addSubview:titleLabel];
    UILabel *lineLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 34, kScreenW, 1)];
    [headerView addSubview:lineLabel];
    lineLabel.backgroundColor = [UIColor groupTableViewBackgroundColor];
    
    titleLabel.textColor = [UIColor blackColor];
    titleLabel.text = [NSString stringWithFormat:@"工单状态>>>%@",[_orderInfo valueForKey:@"status"]];
    titleLabel.font = [UIFont systemFontOfSize:15.0f];
    titleLabel.textAlignment = NSTextAlignmentLeft;
    return headerView;
}

@end
