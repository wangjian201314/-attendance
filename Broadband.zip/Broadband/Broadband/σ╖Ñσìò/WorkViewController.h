//
//  WorkViewController.h
//  Broadband
//
//  Created by 王健 on 2019/5/18.
//  Copyright © 2019年 Mac. All rights reserved.
//
#import "MTBaseViewController.h"
#import <UIKit/UIKit.h>

@interface WorkViewController : MTBaseViewController

@end
