//
//  SCOrderDetailInfoController.h
//  SCATTENDANCE
//
//  Created by mastercom on 2018/4/4.
//  Copyright © 2018年 MasterCom. All rights reserved.
//

#import "MTBaseViewController.h"

@interface SCOrderDetailInfoController : MTBaseViewController

/**
 取下标标识(因管理员与代维字段不一致)
 待处理, 已处理, 已完成,工单查询
 */
@property (nonatomic, assign) NSUInteger operationIndex;

@property (nonatomic, copy) NSString *naviTitle;

@property (nonatomic, copy) NSDictionary *orderInfo;

@property (nonatomic, strong) NSArray *datas;

@end
