//
//  WorkViewController.m
//  Broadband
//
//  Created by 王健 on 2019/5/18.
//  Copyright © 2019年 Mac. All rights reserved.
//

#import "WorkViewController.h"
#import "SCOrderListCell.h"
#import "HBTitleView.h"
#import "SCOrderDetailInfoController.h"
#import <MJRefresh.h>
@interface WorkViewController ()<UITableViewDelegate,UITableViewDataSource>{
    
    UITableView *_mytableview;
    NSArray *_vacationdata;
    NSArray *_outdata;
    NSArray *_workdata;
    NSArray *_workloaddata;
    NSMutableArray *_datasource;
    NSString *_typestr;
}
@property (strong, nonatomic) HBTitleView *hbTitleView;//top
@end

@implementation WorkViewController

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [_mytableview.mj_header beginRefreshing];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
   
    _typestr=@"请假审批";
    _datasource=[NSMutableArray array];
    [self setNaviTitle:@"工单" leftButtonShow:NO rightButtom:nil];
    _mytableview=[[UITableView alloc]initWithFrame:CGRectMake(0, 45, kScreenW, kScreenH-kNavHeight-45-kTabarHeight) style:UITableViewStylePlain];
    _mytableview.delegate=self;
    _mytableview.dataSource=self;
    _mytableview.estimatedRowHeight=200;
    _mytableview.showsVerticalScrollIndicator=NO;
    _mytableview.tableFooterView=[[UIView alloc]initWithFrame:CGRectZero];
    _mytableview.rowHeight=UITableViewAutomaticDimension;
    [self.view addSubview:_mytableview];
    _mytableview.mj_header = [MJRefreshGifHeader  headerWithRefreshingTarget:self refreshingAction:@selector(headerRefresh)];
    [_mytableview.mj_header beginRefreshing];
    [_mytableview registerNib:[UINib nibWithNibName:@"SCOrderListCell" bundle:nil] forCellReuseIdentifier:@"SCOrderListCell"];
   
    
    
}

- (void)headerRefresh{
    
   
    [_datasource removeAllObjects];
     dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [_mytableview.mj_header endRefreshing];
        id namestr=[[NSUserDefaults standardUserDefaults]objectForKey:@"username"];
        if([namestr isEqualToString:@"15976070261"]){
            [self initdata];
        }
         [self.view addSubview:self.hbTitleView];
        [self topbuttonclick];
        [_mytableview reloadData];
    });
    
}
- (HBTitleView *)hbTitleView
{
    if (_hbTitleView == nil)
    {

            _hbTitleView = [[HBTitleView alloc]initWithFrame:CGRectMake(0, 0, kScreenW, 45) andTitles:@[@"请假审批",@"外出审批",@"加班审批",@"工作量审批"]];
        
        [_hbTitleView updataIndexLabelUIWithNum:0];
    }
    return _hbTitleView;
}


- (void)topbuttonclick{
    
        __weak typeof(self)weakSelf = self;
        self.hbTitleView.titleBtnBlock = ^(NSInteger index, NSString *title){
            
            NSLog(@"index:%ld -- title:%@",(long)index,title);
            
            
            switch (index) {
                case 0:{
                    
                    _typestr=@"请假审批";
                    [_datasource removeAllObjects];
                    [_datasource addObjectsFromArray:_vacationdata];
                    [_mytableview reloadData];
                    
                    break;
                }
                case 1:{
                    _typestr=@"外出审批";
                    [_datasource removeAllObjects];
                    [_datasource addObjectsFromArray:_outdata];
                    [_mytableview reloadData];
                }
                    
                   
                    
                    break;
                    
                case 2:{
                    _typestr=@"加班审批";
                    [_datasource removeAllObjects];
                    [_datasource addObjectsFromArray:_workdata];
                    [_mytableview reloadData];
                }
                    
                  
                    
                    break;
                case 3:{
                    _typestr=@"工作量审批";
                    [_datasource removeAllObjects];
                    [_datasource addObjectsFromArray:_workloaddata];
                    [_mytableview reloadData];
                }
                    
                    
                    
                    break;
                    
                    
                default:
                    break;
            }
            
        };
        
        
    
}
- (void)initdata{
    
    _vacationdata=@[@{@"id":@"gdshd73737377355696",
                      @"peple":@"杨兵",
                      @"type":@"调休",
                      @"start":@"2019-5-17 09:30:00",
                       @"end":@"2019-5-18 17:30:00",
                       @"upload":@"2019-5-16 09:30:00",
                       @"status":@"已完成",
                      @"data":@[@"已完成",
                                @"已完成",
                               @"杨兵",
                                @"杨兵plus",
                                @"胡汉科技",
                                @"2019-5-16 09:30:00",
                                @"调休",
                                @"外出旅游",
                                @"2019-5-17 09:30:00",
                               @"2019-5-18 17:30:00",
                                @"2天",
                                @"李部长",
                                @"",
                                @"2019-5-17 09:30:00",
                                @"同意",
                                @"同意",],
                      },
                    @{@"id":@"wer886534521009",
                      @"peple":@"胡兵宏",
                      @"type":@"病假",
                      @"start":@"2019-5-16 09:30:00",
                      @"end":@"2019-5-18 17:30:00",
                      @"upload":@"2019-5-16 09:30:00",
                      @"status":@"申请中",
                      @"data":@[@"申请中",
                                @"申请中",
                                @"胡兵宏",
                                @"胡兵宏03030",
                                @"环球科技",
                                @"2019-5-16 09:30:00",
                                @"病假",
                                @"病假住院",
                                @"2019-5-16 09:30:00",
                                @"2019-5-18 17:30:00",
                                @"3天",
                                @"刘主任",
                                @"",
                                @"2019-5-17 09:30:00",
                                @"",
                                @"",],
                      },
                    @{@"id":@"YY77833800907282",
                      @"peple":@"李四",
                      @"type":@"事假",
                      @"start":@"2019-5-13 09:30:00",
                      @"end":@"2019-5-15 09:30:00",
                      @"upload":@"2019-5-11 09:30:00",
                      @"status":@"准备提交",
                      @"data":@[@"",
                                @"准备提交",
                                @"李四",
                                @"胡李四8830",
                                @"匡威科技",
                                @"2019-5-13 09:30:00",
                                @"事假",
                                @"家中有事回家",
                                @"2019-5-14 09:30:00",
                                @"2019-5-12 17:30:00",
                                @"5天",
                                @"李主任",
                                @"",
                                @"2019-5-17 09:30:00",
                                @"",
                                @"",],
                      },
                    @{@"id":@"gg633638384940900",
                      @"peple":@"张勇",
                      @"type":@"调休",
                      @"start":@"2019-5-13 09:30:00",
                      @"end":@"2019-5-20 09:30:00",
                      @"upload":@"2019-5-17 09:30:00",
                      @"status":@"申请中",
                      @"data":@[@"",
                                @"申请中",
                                @"张勇",
                                @"张勇ufu0",
                                @"盛世科技",
                                @"2019-5-15 09:30:00",
                                @"调休",
                                @"家中有事回家",
                                @"2019-5-15 09:30:00",
                                @"2019-5-17 17:30:00",
                                @"2天",
                                @"李主任",
                                @"",
                                @"2019-5-17 09:30:00",
                                @"",
                                @"",],
                      
                      }];
    [_datasource addObjectsFromArray:_vacationdata];
    [_mytableview reloadData];
    _outdata=@[@{@"id":@"hhhsf633884955959",
                      @"peple":@"王哥",
                      @"type":@"出差南京与客户办事",
                      @"start":@"2019-5-17 09:30:00",
                      @"end":@"2019-5-18 17:30:00",
                      @"upload":@"2019-5-16 09:30:00",
                      @"status":@"已完成",
                 @"data":@[@"",
                           @"hhhsf633884955959",
                           @"2019-5-16 09:30:00",
                           @"已完成",
                           @"王哥",
                           @"王组长",
                           @"王组长183838",
                           @"深刻科技有限公司",
                           @"2019-5-15 09:30:00",
                           @"2019-5-17 17:30:00",
                           @"2019-5-17 17:30:00",
                           @"56小时",
                           @"出差南京与客户办事",                           
                           @"王组长",
                           @"",
                           @"2019-5-17 12:30:00",
                           @"同意",
                           @"ok",],
                 
                      },
                    @{@"id":@"ggddd73735759595",
                      @"peple":@"张雪碧",
                      @"type":@"外出武汉分公司",
                      @"start":@"2019-5-16 09:30:00",
                      @"end":@"2019-5-18 17:30:00",
                      @"upload":@"2019-5-16 09:30:00",
                      @"status":@"申请中",
                      @"data":@[@"",
                                @"ggddd73735759595",
                                @"2019-5-16 09:30:00",
                                @"申请中",
                                @"张雪碧",
                                @"王处长",
                                @"王处长183838",
                                @"小加科技有限公司",
                                @"2019-5-15 09:30:00",
                                @"2019-5-17 17:30:00",
                                @"2019-5-17 17:30:00",
                                @"56小时",
                                @"外出武汉分公司",
                                @"王处长",
                                @"",
                                @"2019-5-17 12:30:00",
                                @"",
                                @"",],
                      },
                    @{@"id":@"hgue634505723749",
                      @"peple":@"李哥",
                      @"type":@"国外出差",
                      @"start":@"2019-5-13 09:30:00",
                      @"end":@"2019-5-15 09:30:00",
                      @"upload":@"2019-5-11 09:30:00",
                      @"status":@"申请中",
                      @"data":@[@"",
                                @"hgue634505723749",
                                @"2019-5-16 09:30:00",
                                @"申请中",
                                @"李哥",
                                @"张科长",
                                @"张科长fjfj8",
                                @"小行科技公司",
                                @"2019-5-15 09:30:00",
                                @"2019-5-17 13:30:00",
                                @"2019-5-12 17:30:00",
                                @"44小时",
                                @"国外出差",
                                @"张科长",
                                @"",
                                @"2019-5-18 12:30:00",
                                @"",
                                @"",],
                      },
                    @{@"id":@"hgdd6378629349",
                      @"peple":@"张全",
                      @"type":@"黑龙江出差办事",
                      @"start":@"2019-5-13 09:30:00",
                      @"end":@"2019-5-20 09:30:00",
                      @"upload":@"2019-5-17 09:30:00",
                      @"status":@"申请中",
                      @"data":@[@"",
                                @"hgdd6378629349",
                                @"2019-5-13 09:30:00",
                                @"申请中",
                                @"张全",
                                @"张处长",
                                @"张处长fjfj8",
                                @"小行科技公司",
                                @"2019-5-14 09:30:00",
                                @"2019-5-18 13:30:00",
                                @"2019-5-11 17:30:00",
                                @"38小时",
                                @"黑龙江出差办事",
                                @"周组长",
                                @"",
                                @"2019-5-18 12:30:00",
                                @"",
                                @"",],
                      }];
    _workdata=@[@{@"id":@"jhdfj63284295792",
                      @"peple":@"王富贵",
                      @"type":@"工作量未完成",
                      @"start":@"2019-5-17 09:30:00",
                      @"end":@"2019-5-18 17:30:00",
                      @"upload":@"2019-5-16 09:30:00",
                      @"status":@"申请中",
                  @"data":@[@"",
                            @"hgdd6378629349",
                            @"2019-5-13 09:30:00",
                            @"申请中",
                            @"张全",
                            @"张处长",
                            @"小行科技公司",
                            @"2019-5-14 09:30:00",
                            @"2019-5-18 13:30:00",
                            @"2019-5-11 17:30:00",
                            @"38小时",
                            @"否",
                            @"正常上班",
                            @"工作量未完成",
                            @"周组长",
                            @"",
                            @"",
                            @"2019-5-18 12:30:00",
                            @"",
                            @"",],
                      },
                    @{@"id":@"gdkdkd25253844949",
                      @"peple":@"李明",
                      @"type":@"公司临时任务",
                      @"start":@"2019-5-16 09:30:00",
                      @"end":@"2019-5-18 17:30:00",
                      @"upload":@"2019-5-16 09:30:00",
                      @"status":@"已完成",
                      @"data":@[@"",
                                @"gdkdkd25253844949",
                                @"2019-5-16 09:30:00",
                                @"已完成",
                                @"李明",
                                @"李主任",
                                @"福安科技公司",
                                @"2019-5-15 09:30:00",
                                @"2019-5-16 13:30:00",
                                @"2019-5-16 17:30:00",
                                @"46小时",
                                @"是",
                                @"双倍薪资",
                                @"公司临时任务",
                                @"李主任",
                                @"",
                                @"",
                                @"2019-5-18 12:30:00",
                                @"同意",
                                @"同意",],
                      },
                    @{@"id":@"gg3659483382949",
                      @"peple":@"李春梅",
                      @"type":@"月底干业绩",
                      @"start":@"2019-5-13 09:30:00",
                      @"end":@"2019-5-15 12:30:00",
                      @"upload":@"2019-5-16 09:30:00",
                      @"status":@"准备提交",
                      @"data":@[@"",
                                @"gg3659483382949",
                                @"2019-5-16 09:30:00",
                                @"准备提交",
                                @"李春梅",
                                @"李主任",
                                @"福特科技公司",
                                @"2019-5-12 09:30:00",
                                @"2019-5-17 13:30:00",
                                @"2019-5-18 17:30:00",
                                @"89小时",
                                @"否",
                                @"正常薪资",
                                @"月底干业绩",
                                @"李主任",
                                @"",
                                @"",
                                @"2019-5-17 12:30:00",
                                @"",
                                @"",],
                      },
                    @{@"id":@"hdgfjd632872572928",
                      @"peple":@"张单",
                      @"type":@"领导说要加班",
                      @"start":@"2019-5-13 09:30:00",
                      @"end":@"2019-5-20 09:30:00",
                      @"upload":@"2019-5-17 09:30:00",
                      @"status":@"已完成",
                      @"data":@[@"",
                                @"hdgfjd632872572928",
                                @"2019-5-16 09:30:00",
                                @"已完成",
                                @"张单",
                                @"张经理",
                                @"凯尔科技公司",
                                @"2019-5-15 09:30:00",
                                @"2019-5-16 13:30:00",
                                @"2019-5-17 17:30:00",
                                @"24小时",
                                @"否",
                                @"3倍薪资",
                                @"领导说要加班",
                                @"张经理",
                                @"",
                                @"",
                                @"2019-5-17 12:30:00",
                                @"",
                                @"",],
                      }];
    
    _workloaddata=@[@{@"id":@"gdshd73ddj377355696",
                      @"peple":@"杨林",
                      @"type":@"年销量100万",
                      @"start":@"2019-5-17 09:30:00",
                      @"end":@"2019-5-18 17:30:00",
                      @"upload":@"2019-5-16 09:30:00",
                      @"status":@"已完成",
                      @"data":@[@"",
                                @"2019-5-16 09:30:00",
                                @"已完成",
                                @"张单",
                                @"2019-5-17 09:30:00",
                                @"凯尔科技公司",
                                @"森森科技公司",
                                @"大数据",
                                @"大数据一部",
                                @"2019-5-15 09:30:00",
                                @"2019-5-16 13:30:00",
                                @"销售业绩感人，成功超出销售额度",
                                @"80小时",
                                @"刘经理",
                                @"",
                                @"是",
                                @"是的",
                                @"该员工主动积极完成超额任务，值得鼓励!",
                                @"考虑提拔",
                                @"2019-5-17 12:30:00",
                                ],
                      },
                    @{@"id":@"ghjssj2283494",
                      @"peple":@"杨山",
                      @"type":@"上线10个项目",
                      @"start":@"2019-5-16 09:30:00",
                      @"end":@"2019-5-18 17:30:00",
                      @"upload":@"2019-5-16 09:30:00",
                      @"status":@"申请中",
                      @"data":@[@"",
                                @"2019-5-16 09:30:00",
                                @"申请中",
                                @"杨山",
                                @"2019-5-17 09:30:00",
                                @"吱吱科技公司",
                                @"航科科技公司",
                                @"科研部分",
                                @"app开发部",
                                @"2019-5-13 09:30:00",
                                @"2019-5-17 13:30:00",
                                @"一周上线了5个项目，成功超过计划量",
                                @"65小时",
                                @"李经理",
                                @"",
                                @"是",
                                @"是的",
                                @"各方面表现不错，值得深造，项目完成的非常好，代码整洁，非常靠谱!",
                                @"升职加薪",
                                @"2019-5-16 12:30:00",
                                ],
                      },
                    @{@"id":@"hfhhf373939239",
                      @"peple":@"李好",
                      @"type":@"一个月200万的营业额",
                      @"start":@"2019-5-13 09:30:00",
                      @"end":@"2019-5-15 09:30:00",
                      @"upload":@"2019-5-11 09:30:00",
                      @"status":@"准备提交",
                      @"data":@[@"",
                                @"2019-5-16 09:30:00",
                                @"准备提交",
                                @"李好",
                                @"2019-5-11 09:30:00",
                                @"顺风科技公司",
                                @"xx销售有限公司",
                                @"销售部",
                                @"xx销售一部",
                                @"2019-5-13 09:30:00",
                                @"2019-5-17 13:30:00",
                                @"一个月200万的营业额",
                                @"55小时",
                                @"刘经理",
                                @"",
                                @"暂时没有",
                                @"暂时没有",
                                @"年轻人有梦想，值得提倡，但是还是要稳住，切勿心浮气躁",
                                @"调往其他部门锻炼",
                                @"2019-5-16 12:30:00",
                                ],
                      },
                    @{@"id":@"hdhj638389494",
                      @"peple":@"张稳",
                      @"type":@"客户量200万单",
                      @"start":@"2019-5-13 09:30:00",
                      @"end":@"2019-5-20 09:30:00",
                      @"upload":@"2019-5-17 09:30:00",
                      @"status":@"申请中",
                      @"data":@[@"",
                                @"2019-5-16 09:30:00",
                                @"申请中",
                                @"张稳",
                                @"2019-5-11 09:30:00",
                                @"歪歪科技公司",
                                @"xx销售有限公司",
                                @"销售部",
                                @"xx销售二部",
                                @"2019-5-15 09:30:00",
                                @"2019-5-19 13:30:00",
                                @"客户量200万单",
                                @"60小时",
                                @"李部长",
                                @"",
                                @"是",
                                @"是的",
                                @"年轻人有干劲，应该多得多鼓励，抓住机遇才能走向梦想的巅峰",
                                @"可以给与其机会，多多磨炼提高能力!",
                                @"2019-5-16 12:30:00",
                                ],
                      }];



}

#pragma mark - UITableView Datasource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _datasource.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    
    SCOrderListCell *cell = [tableView dequeueReusableCellWithIdentifier:@"SCOrderListCell"];
    
    if(cell == nil) {
        cell = [[SCOrderListCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"SCOrderListCell"];
    }
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    cell.typestr=_typestr;
    cell.keys=@[@"id",@"peple",@"type",@"start",@"end",@"upload",@"status"];
    cell.valueDic=_datasource[indexPath.row];
    
    return cell;
}

#pragma mark - UITableView Delegate methods

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    SCOrderDetailInfoController *vc=[SCOrderDetailInfoController new];
    vc.orderInfo=_datasource[indexPath.row];
    vc.naviTitle=_typestr;
    vc.datas=_datasource[indexPath.row][@"data"];
    [self pushViewController:vc];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
