//
//  HBDFMultiRowLabelCell.h
//  ZSWXWLKH
//
//  Created by mastercom on 2018/4/3.
//  Copyright © 2018年 MasterCom. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HBDFMultiRowLabelCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *titleNameLabel;
@property (weak, nonatomic) IBOutlet UILabel *valueLabel;
@property (weak, nonatomic) IBOutlet UILabel *bottomLineLabel;

// 默认隐藏 星标
@property (weak, nonatomic) IBOutlet UIImageView *flagImageVIew;

@end
