//
//  HBDFMultiRowLabelCell.m
//  ZSWXWLKH
//
//  Created by mastercom on 2018/4/3.
//  Copyright © 2018年 MasterCom. All rights reserved.
//

#import "HBDFMultiRowLabelCell.h"

@implementation HBDFMultiRowLabelCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    self.flagImageVIew.hidden = YES;
    self.selectionStyle = UITableViewCellSelectionStyleNone;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
