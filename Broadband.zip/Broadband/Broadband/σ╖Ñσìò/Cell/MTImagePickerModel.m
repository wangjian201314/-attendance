//
//  MTImagePickerModel.m
//  GDWWNOP
//
//  Created by QinJ on 2017/8/10.
//  Copyright © 2017年 cn.mastercom. All rights reserved.
//

#import "MTImagePickerModel.h"

@implementation MTImagePickerModel

@end
