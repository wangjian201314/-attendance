//
//  SCOrderListCell.m
//  SCATTENDANCE
//
//  Created by mastercom on 2018/4/4.
//  Copyright © 2018年 MasterCom. All rights reserved.
//

#import "SCOrderListCell.h"


@interface SCOrderListCell()

@property (strong, nonatomic) IBOutletCollection(UILabel) NSArray *titleLabels;
@property (strong, nonatomic) IBOutletCollection(UILabel) NSArray *valueLabels;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *lastrowHeight;
@property (weak, nonatomic) IBOutlet UILabel *typelb;


@end

@implementation SCOrderListCell

- (void)setValueDic:(NSDictionary *)valueDic
{
    if([_keys count] == 0) return;

    for (int i = 0; i < [_titleLabels count]; i ++)
    {
        UILabel *titleLabel = [_titleLabels objectAtIndex:i];
        UILabel *valueLabel = [_valueLabels objectAtIndex:i];
        
        if(i > [_keys count] - 1) // 仅适配最后一行
        {
            _lastrowHeight.constant = 0.0f;
            titleLabel.hidden = NO;
            valueLabel.hidden = NO;
            break;
        }
        
        NSString *title = [_keys objectAtIndex:i];
       // titleLabel.text = [NSString stringWithFormat:@"%@:",title];
        valueLabel.text = isnull([valueDic valueForKey:title]);
    }
    
    if([_typestr isEqualToString:@"请假审批"]){
         self.typelb.text=@"请假类型:";
    }else if([_typestr isEqualToString:@"外出审批"]){
        self.typelb.text=@"外出原因:";
        
    }else if([_typestr isEqualToString:@"加班审批"]){
         self.typelb.text=@"加班理由:";
        
    }else if([_typestr isEqualToString:@"工作量审批"]){
         self.typelb.text=@"工作量申请:";
        
    }
}
- (IBAction)select:(UIButton *)sender {
    
    
}


- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
