//
//  MTBaseViewController.h
//  First
//
//  Created by 王健 on 2019/3/23.
//  Copyright © 2019年 王健. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MTBaseViewController : UIViewController

- (void)setNaviTitle:(NSString*)title leftButtonShow:(BOOL)leftButtonShow rightButtom:(id)rightButtom;
- (void)backAction;
- (void)pushViewController:(UIViewController *)vc;
- (void)saveLocalData:(NSMutableDictionary *) dict;//保存
- (NSDictionary *)getLocalData ;//取值
@property(nonatomic,copy)NSString *navititle;
@end
