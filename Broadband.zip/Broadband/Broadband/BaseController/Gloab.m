//
//  Gloab.m
//  Broadband
//
//  Created by Mac on 2019/5/17.
//  Copyright © 2019年 Mac. All rights reserved.
//

#import "Gloab.h"

@implementation Gloab

#pragma mark -- 获取字符串高度
CGFloat heightForString(NSString *value, CGFloat fontSize, CGFloat width)
{
    UIColor  *backgroundColor=[UIColor blackColor];
    UIFont *font = [UIFont boldSystemFontOfSize:fontSize];
    CGRect sizeToFit = [value boundingRectWithSize:CGSizeMake(width, CGFLOAT_MAX) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{
                                                                                                                                             NSForegroundColorAttributeName:backgroundColor,
                                                                                                                                             NSFontAttributeName:font
                                                                                                                                             } context:nil];
    return sizeToFit.size.height+1;
}
@end
