//
//  MTBaseViewController.m
//  First
//
//  Created by 王健 on 2019/3/23.
//  Copyright © 2019年 王健. All rights reserved.
//

#import "MTBaseViewController.h"

@interface MTBaseViewController ()<UIGestureRecognizerDelegate>{
    
     NSArray* _leftBarItems;
}

@end

@implementation MTBaseViewController

- (id)initWithNibName:(NSString*)nibNameOrNil bundle:(NSBundle*)nibBundleOrNil
{
    NSLog(@"❤️-----%@-----", [self class]);
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        if (NSFoundationVersionNumber > NSFoundationVersionNumber_iOS_6_1) {
            self.edgesForExtendedLayout = UIRectEdgeNone;
            self.automaticallyAdjustsScrollViewInsets = NO;
        }
      //  navigationBarHidden = YES;
    }
    return self;
}
- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    
    if ([self.navigationController respondsToSelector:@selector(interactivePopGestureRecognizer)]) {
        self.navigationController.interactivePopGestureRecognizer.delegate = nil;
    }
    
    @try {
//        if ([SVProgressHUD isVisible]) {
//            [SVProgressHUD dismiss];
//        }
    }
    @catch (NSException* exception) {
    }
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    //self.navigationController.navigationBarHidden = navigationBarHidden;
}
- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    if ([self.navigationController respondsToSelector:@selector(interactivePopGestureRecognizer)]) {
        //只有在二级页面生效
        if ([self.navigationController.viewControllers count] == 2) {
            self.navigationController.interactivePopGestureRecognizer.delegate = self;
        }
    }
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self setupBaseView];
     self.navigationController.navigationBar.alpha = 1;
    self.view.backgroundColor=[UIColor colorWithHexString:@"#FAE8E7"];
    [self setNavigationBarWithColor:[UIColor colorWithHexString:@"#4182F7"]];
}

- (void)setupBaseView {
    
    
    if (self) {
        if (NSFoundationVersionNumber > NSFoundationVersionNumber_iOS_6_1) {
            self.edgesForExtendedLayout = UIRectEdgeNone;
            self.automaticallyAdjustsScrollViewInsets = NO;
        }
    }
    
    NSArray * ledtItems = [self setupLeftBarItems];
    
    self.navigationItem.leftBarButtonItems = ledtItems;
    _leftBarItems = ledtItems;
    
    
    //[self setUpForDismissKeyboard];
}

- (NSArray *)setupLeftBarItems {
    UIImage * icon  = [UIImage imageNamed:@"back"];
    UIBarButtonItem* item = [[UIBarButtonItem alloc] initWithImage:icon style:UIBarButtonItemStylePlain target:self action:@selector(backAction)];
        return@[item];
}
- (void)backAction
{
    
    [self.navigationController popViewControllerAnimated:YES];

}

- (void)pushViewController:(UIViewController*)vc
{
    //[SVProgressHUD dismiss];
    //如果在tab页下,默认
    if (self.tabBarItem) {
        vc.hidesBottomBarWhenPushed = YES;
    }
    
    
    if ([self.navigationController respondsToSelector:@selector(interactivePopGestureRecognizer)]) {
        self.navigationController.interactivePopGestureRecognizer.enabled = NO;
    }
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)setNaviTitle:(NSString*)title leftButtonShow:(BOOL)leftButtonShow rightButtom:(id)rightButtom {
    //navigationBarHidden = NO;
    if (!leftButtonShow) {
        _leftBarItems = self.navigationItem.leftBarButtonItems;
        self.navigationItem.leftBarButtonItem = nil;
        self.navigationItem.hidesBackButton = YES;
    }
    else {
        self.navigationItem.leftBarButtonItems = _leftBarItems;
        self.navigationItem.hidesBackButton = NO;
    }
    
    [self.navigationItem setRightBarButtonItem:rightButtom];
    
    self.navigationItem.title = title;
    
    /*01 根据title的长度来计算是否需要滚动title
     02 需要满足 isScrollTitleLabel 属性为 YES
     满足 1 2 条件才可执行以下方法
     **/
    
}

- (void)setNavititle:(NSString *)navititle{
    self.navigationItem.title = navititle;
}
- (void)setNavigationBarWithColor:(UIColor*)color
{
    UIImage* image = [self imageWithColor:color];
    
    [self.navigationController.navigationBar setBackgroundImage:image forBarMetrics:UIBarMetricsDefault];
    [self.navigationController.navigationBar setBarStyle:UIBarStyleDefault];
    [self.navigationController.navigationBar setShadowImage:[UIImage new]];
    [self.navigationController.navigationBar setTitleTextAttributes:@{ NSForegroundColorAttributeName : [UIColor whiteColor] }];
    [self.navigationController.navigationBar setTintColor:[UIColor whiteColor]];
    
    [self.navigationController.navigationBar setTranslucent:YES];
}
- (UIImage*)imageWithColor:(UIColor*)color
{
    CGRect rect = CGRectMake(0, 0, 1, 1);
    UIGraphicsBeginImageContextWithOptions(rect.size, NO, 0);
    [color setFill];
    UIRectFill(rect);
    
    UIImage* image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return image;
}



-(UIInterfaceOrientationMask)supportedInterfaceOrientations{
    return UIInterfaceOrientationMaskPortrait;
}

- (BOOL)shouldAutorotate
{
    return NO;
}

-(UIInterfaceOrientation)preferredInterfaceOrientationForPresentation
{
    return UIInterfaceOrientationPortrait;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (void)saveLocalData:(NSMutableDictionary *) dict{
    
    NSString *path = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)[0];
    NSString *filePath = [path stringByAppendingPathComponent:@"image.plist"];
    [dict writeToFile:filePath atomically:YES];
    
    //准备存储数据的对象
    NSMutableData *data = [NSMutableData data];
    //创建归档对象
    NSKeyedArchiver *archiver = [[NSKeyedArchiver alloc] initForWritingWithMutableData:data];
    //开始归档
    [archiver encodeObject:dict forKey:@"uploadDict"];
    //完成归档
    [archiver finishEncoding];
    //写入文件当中
    BOOL result = [data writeToFile:filePath atomically:YES];
    if (result) {
        NSLog(@"归档成功:%@",path);
    }else
    {
        NSLog(@"归档不成功!!!");
    }
    
}

- (NSDictionary *)getLocalData {
    NSDictionary *dic;
    //    dispatch_async(dispatch_get_global_queue(0, 0), ^{
    
    NSString *path = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)[0];
    
    NSString *filePath =  [path stringByAppendingPathComponent:@"image.plist"];
    NSData *myData = [NSData dataWithContentsOfFile:filePath];
    //创建反归档对象
    NSKeyedUnarchiver *unarchiver = [[NSKeyedUnarchiver alloc] initForReadingWithData:myData];
    //反归档
    dic = [unarchiver decodeObjectForKey:@"uploadDict"];
    //完成反归档
    [unarchiver finishDecoding];
    
    //    });
    return  dic;
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
