//
//  HTTPRequestManager.h
//  ChaoLiuNvZhuang1521
//
//  Created by iJeff on 15/11/20.
//  Copyright (c) 2015年 iJeff. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef void(^ResultBlock)(id responseObj, NSError *error);

@interface HTTPRequestManager : NSObject


//GET
+ (void)GET:(NSString *)url parameters:(id)parameters result:(ResultBlock)result;

+ (void)Post:(NSString *)url parameters:(id)parameters result:(ResultBlock)result;

@end













