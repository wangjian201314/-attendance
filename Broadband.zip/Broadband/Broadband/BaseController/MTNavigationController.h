//
//  MTNavigationController.h
//  MTNOP
//
//  Created by renwanqian on 14-4-16.
//  Copyright (c) 2014年 cn.mastercom. All rights reserved.
//


#import <UIKit/UIKit.h>

@interface MTNavigationController : UINavigationController

@end
