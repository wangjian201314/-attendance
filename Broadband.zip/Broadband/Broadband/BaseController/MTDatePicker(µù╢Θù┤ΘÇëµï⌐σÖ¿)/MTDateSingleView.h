//
//  MTDateSingleView.h
//  ZSWXWLKH
//
//  Created by kingste on 2017/6/14.
//  Copyright © 2017年 MasterCom. All rights reserved.
//



#import <UIKit/UIKit.h>
#import "NSDate+Extension.h"
#import "MTdateHeader.h"

@class MTDateSingleView;
@protocol MTDateSingleViewDelegate <NSObject>
/*
 选择 代理方式初始化时 实现下面方法接收回调
 */
- (void)MTDateSingleView:(MTDateSingleView *)dateSingleView didSelectedDate:(NSDate *)date;

@end

@interface MTDateSingleView : UIView

//============ 方式一  Block 形式进行回调============
- (instancetype)initWithDateStyle:(MTDateStyle)datePickerStyle DateHandler:(DateHandler)dateHandler;
@property (nonatomic, strong) DateHandler dateHandler;

//============ 方式二  Delegate 形式进行回调============
- (instancetype)initWithDateStyle:(MTDateStyle)datePickerStyle delegate:(id)delegate;
@property (nonatomic, assign)id<MTDateSingleViewDelegate>delegate;


@property (nonatomic, strong) NSDate * date;

@property (nonatomic, retain) NSDate *maxLimitDate;//限制最大时间 默认9999
@property (nonatomic, retain) NSDate *minLimitDate;//限制最小时间 默认0

- (void)show;
- (void)dismiss;

@end
