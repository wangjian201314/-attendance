//
//  ExpendButton.m
//  MTCommon
//
//  Created by lvyazhou on 2018/7/9.
//  Copyright © 2018年 郭文超. All rights reserved.
//

#import "ExpendButton.h"

@implementation ExpendButton

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/
-(BOOL)pointInside:(CGPoint)point withEvent:(UIEvent *)event
{
    CGRect bounds = self.bounds;
    
    bounds = CGRectInset(bounds, -20, -20);
    
    return CGRectContainsPoint(bounds, point);
}


@end
