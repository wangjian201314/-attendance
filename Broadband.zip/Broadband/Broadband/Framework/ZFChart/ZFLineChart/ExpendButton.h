//
//  ExpendButton.h
//  MTCommon
//
//  Created by lvyazhou on 2018/7/9.
//  Copyright © 2018年 郭文超. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ExpendButton : UIControl

@end
